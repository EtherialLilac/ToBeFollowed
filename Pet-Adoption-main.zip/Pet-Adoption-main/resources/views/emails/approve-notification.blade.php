<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h2>Subject: Pet Adoption Approval Confirmation</h2>

    <p>Dear Adopter {{ $adoption->adopt_name }}</p>
    <p>
        I am thrilled to announce that your application for pet adoption has been carefully assessed, and I am delighted
        to grant approval for the adoption of {{ $pet->name }}.
    </p>
    <p>Your genuine affection for animals, coupled with your commitment to providing a loving and caring home, makes you
        an ideal candidate for welcoming {{ $pet->name }} into your family.
    </p>
    <p>Attached, you will find the necessary documentation outlining further details and guidance on the upcoming steps
        in the pet adoption process. If you have any questions or need additional information, please do not hesitate to
        reach out.
    </p>
    <p>Congratulations on this exciting journey, and we are confident that{{ $pet->name }} will bring immense joy and
        companionship into your life.
    </p>
    <p>Best regards,
    </p>

    <p>{{ auth()->user()->name }}</p>
    <p>Cats of New Port</p>

    <p>Appointment Date : {{ \Carbon\Carbon::parse($adoption->updated_at)->addDays(3) }} </p>



    <a href="{{ route('welcome') }}">Cart of New port</a>
</body>

</html>
