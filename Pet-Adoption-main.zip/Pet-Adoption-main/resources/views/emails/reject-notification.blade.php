<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h2>Subject: Pet Adoption Application Status</h2>

    <p> Dear {{ $adoption->adopt_name }},</p>

    <p> I hope this message finds you well. After careful consideration of your application for the adoption of Pet's,
        we regret to inform you that your application has not been approved at this time.
    </p>
    <p>While we genuinely appreciate your interest in providing a loving home for {{ $pet->name }}, our decision is
        based on
        various factors, including the specific needs and requirements of the pet, as well as the information provided
        in
        your application.</p>

    <p>We understand that this may be disappointing, and we want to assure you that this decision does not reflect
        negatively on your suitability as a pet owner. Our aim is to ensure the well-being and happiness of the animals
        in
        our care, and sometimes this involves making challenging decisions.</p>

    <p>If you have any questions or would like feedback on your application, please feel free to reach out. We
        appreciate
        your understanding and thank you for considering adoption.</p>

    <p>Best regards,</p>

    <p>{{ auth()->user()->name }}</p>

    <a href="{{ route('welcome') }}">Cart of New port</a>
</body>

</html>
