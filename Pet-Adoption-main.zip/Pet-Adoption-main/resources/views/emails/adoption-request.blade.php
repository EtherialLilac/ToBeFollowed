<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h2>Subject: Pet Adoption Application - Under Review</h2>

    <p>Dear Applicant, {{ auth()->user()->name }}</p>

    <p>I hope this message finds you well. Thank you for submitting your application for the request for fostering, We
        appreciate your interest in providing a loving home for our furry friends.</p>

    <p>I wanted to inform you that your application is currently under review. Our team is carefully assessing all
        aspects to ensure the best possible match between adopters and pets. This process may take some time as we
        strive to make thoughtful and responsible decisions.</p>

    <p>We understand the anticipation that comes with awaiting a decision, and we appreciate your patience during this
        time. Rest assured, we are dedicated to finding the most suitable homes for our pets.</p>

    <p>If there are any additional details required or if we need to clarify any information from your application, we
        will reach out to you promptly. Thank you for your understanding and commitment to providing a caring
        environment for our pet</p>

    <p>Thank you for submitting an adoption request for the pet named {{ $pet->name }}.</p>

    <p>Best regards,</p>

    <p>Your Pet Adoption Team</p>

    <p>[CATS OF NEWPORT]</p>

    <p>[APPLICATION UNDER REVIEW]</p>

    <a href="{{ route('welcome') }}">Cart of New port</a>
</body>

</html>
