<x-app-layout>
    <livewire-intake />
</x-app-layout>
