<x-guest-layout>
    @section('page-title')
        <title>{{ __('NewPort - Register') }}</title>
    @endsection
    <div class="flex flex-wrap-reverse sm:flex-wrap dark:bg-gray-900">
        <!-- Left Side with Background -->
        <div data-aos="fade-right" data-aos-duration="1500"
            class="w-full md:w-1/2 h-screen background-pattern hidden md:block">
            <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706785169/Pets-1-1200x800_nre0ej.jpg"
                class="object-cover w-full h-full" alt="">
        </div>

        <!-- Right Side with Login Form -->
        <div data-aos="fade-left" data-aos-duration="1500"
            class="w-full md:w-1/2 h-screen flex justify-center items-center mt-10">
            <div class="w-full max-w-md">
                <div class="bg-white dark:bg-gray-800 shadow-md rounded px-8 pt-6 pb-8 mb-4">
                    <h2 class="text-2xl font-bold text-slate-800 mb-6">
                        <p
                            class="self-center text-3xl font-semibold whitespace-nowrap dark:text-white uppercase font-palanquin">
                            <span class="font-pacifico text-blue-700 text-6xl">C</span>ats of Newport
                        </p>
                        <span class="uppercase text-gray-500 font-sans text-md ml-12 font-bold">Register TO Newport
                            APP</span>
                    </h2>
                    <form class="w-full" method="POST" action="{{ route('register') }}" id="registerForm">
                        @csrf
                        {{-- Name with Validation Only Letter are allowed to input  --}}
                        <div>
                            <x-label class="text-black dark:text-white" for="name" value="{{ __('Name') }}" />
                            <x-input id="name" class="block mt-1 w-full dark:text-black" type="text"
                                name="name" placeholder="Surname, First Name Middle Name" :value="old('name')" required
                                autofocus autocomplete="name" onkeypress="return onlyLetters(event)" />
                            @error('name')
                                <span class="text-red-500 text-xs">{{ $message }}</span>
                            @enderror
                        </div>

                        <script>
                            function onlyLetters(event) {
                                var char = String.fromCharCode(event.which);
                                if (!(/[a-zA-Z ]/.test(char))) {
                                    event.preventDefault();
                                }
                            }
                        </script>

                        <div class="mt-4">
                            <x-label class="text-black dark:text-white" for="email" value="{{ __('Email') }}" />
                            <x-input id="email" class="block mt-1 w-full dark:text-black" type="email"
                                name="email" :value="old('email')" placeholder='Enter your Email' required
                                autocomplete="username" />
                            @error('email')
                                <span class="text-red-500 text-xs">{{ $message }}</span>
                            @enderror
                        </div>

                        <script>
                            function onlyNumbers(event) {
                                var char = String.fromCharCode(event.which);
                                if (!(/[0-9]/.test(char))) {
                                    event.preventDefault();
                                }
                            }

                            function limitLength(elem) {
                                if (elem.value.length > 6) {
                                    elem.value = elem.value.slice(0, 6);
                                }
                            }
                        </script>

                        <div class="mt-4">
                            <x-label class="text-black dark:text-white" for="password" value="{{ __('Password') }}" />
                            <x-input id="password" class="block mt-1 w-full" type="password" name="password" required
                                autocomplete="new-password" />
                            @error('password')
                                <span class="text-red-500 text-xs">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="mt-4">
                            <x-label class="text-black dark:text-white" for="password_confirmation"
                                value="{{ __('Confirm Password') }}" />
                            <x-input id="password_confirmation" class="block mt-1 w-full" type="password"
                                name="password_confirmation" required autocomplete="new-password" />
                            @error('password_confirmation')
                                <span class="text-red-500 text-xs">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white" for="file_input">Upload Valid ID</label>
                            <input wire:model="file" type="file" id="valid_id" name="valid_id" class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400">
                            @error('file') <span class="text-red-500">{{ $message }}</span> @enderror
                        </div>

                        <div class="flex items-center justify-between mt-4">
                            <button
                                class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                type="submit">
                                Register

                            </button>
                        </div>
                        @if (Laravel\Jetstream\Jetstream::hasTermsAndPrivacyPolicyFeature())
                            <div class="mt-4">
                                <x-label for="terms">
                                    <div class="flex items-center">
                                        <x-checkbox name="terms" id="terms" required />

                                        <div class="ms-2">
                                            {!! __('I agree to the :terms_of_service and :privacy_policy', [
                                                'terms_of_service' =>
                                                    '<a target="_blank" href="' .
                                                    route('terms.show') .
                                                    '" class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800">' .
                                                    __('Terms of Service') .
                                                    '</a>',
                                                'privacy_policy' =>
                                                    '<a target="_blank" href="' .
                                                    route('policy.show') .
                                                    '" class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800">' .
                                                    __('Privacy Policy') .
                                                    '</a>',
                                            ]) !!}
                                        </div>
                                    </div>
                                </x-label>
                            </div>
                        @endif
                    </form>
                    <div class="mt-4">
                        <p class="text-center font-bold text-sm dark:text-white">
                            Already have an Account? <span class="text-blue-500 hover:text-blue-800 cursor-pointer"
                                onclick="window.location='/login'"> Sign In</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-guest-layout>
