<x-guest-layout>
    @section('page-title')
        <title>{{ __('NewPort - Login') }}</title>
    @endsection
    <div class="flex flex-wrap-reverse sm:flex-wrap dark:bg-gray-900">
        <!-- Left Side with Background -->
        <div data-aos="fade-right" data-aos-duration="1500"
            class="w-full md:w-1/2 h-screen background-pattern hidden md:block">
            <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706785169/Pets-1-1200x800_nre0ej.jpg"
                class="object-cover w-full h-full" alt="">
        </div>

        <!-- Right Side with Login Form -->
        <div data-aos="fade-left" data-aos-duration="1500"
            class="w-full md:w-1/2 h-screen flex justify-center items-center">
            <div class="w-full max-w-md">
                <div class="bg-white dark:bg-gray-800 shadow-md rounded px-8 pt-6 pb-8 mb-4">
                    {{-- Message --}}
                    @if (session()->has('success'))
                        <div x-data="{ isOpen: true }" x-init="setTimeout(() => isOpen = false, 3000)" x-show="isOpen" id="alert-border-3"
                            class="flex items-center p-4 mb-4 text-green-800 border-t-4 border-green-300 bg-green-50 dark:text-green-400 dark:bg-gray-800 dark:border-green-800"
                            role="alert">
                            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                            </svg>
                            <div class="ms-3 text-sm font-medium">
                                {{ session('success') }}
                            </div>
                            <button type="button"
                                class="ms-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-green-400 dark:hover:bg-gray-700"
                                data-dismiss-target="#alert-border-3" aria-label="Close">
                                <span class="sr-only">Dismiss</span>
                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 14 14">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                </svg>
                            </button>
                        </div>
                    @endif
                    {{-- End message --}}
                    <h2 class="text-2xl font-bold text-slate-800 mb-16">
                        <p
                            class="self-center text-3xl font-semibold whitespace-nowrap dark:text-white uppercase font-palanquin">
                            <span class="font-pacifico text-blue-700 text-7xl">C</span>ats of NewPort
                        </p>
                        <span class="uppercase text-gray-500 font-sans text-md ml-12 font-bold">LOGIN TO NewPort
                            APP</span>
                    </h2>
                    <form action="{{ route('login') }}" method="POST">
                        @csrf
                        <div class="mt-4 dark:text-white">
                            <x-label for="email" value="{{ __('Email') }}" class="text-black dark:text-white" />
                            <x-input id="email" class="block mt-1 w-full dark:text-black" type="email"
                                name="email" :value="old('email')" required autocomplete="username" />
                        </div>

                        <div class="mt-4">
                            <x-label for="password" value="{{ __('Password') }}" class="text-black dark:text-white" />
                            <x-input id="password" class="block mt-1 w-full dark:text-black" type="password"
                                name="password" required autocomplete="new-password" />
                        </div>
                        <span class="text-xs dark:text-white hover:text-blue-500 hover:underline cursor-pointer"
                            onclick="window.location='{{ route('password.request') }} '">Forgot Password?</span>
                        <div class="flex items-center justify-between mt-4">
                            <button
                                class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                type="submit">
                                Log In
                            </button>
                        </div>
                        <div class="mt-4">
                            {{-- <button class="text-black dark:text-white font-bold py-2 px-4 w-full rounded border "
                                type="button">
                                Continue With Google
                            </button> --}}
                            <p class="text-center font-bold text-sm my-4 dark:text-white">
                                Don't have an Account? <span class="text-blue-500 hover:text-blue-800 cursor-pointer"
                                    onclick="window.location='/register'"> Sign Up</span>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</x-guest-layout>
