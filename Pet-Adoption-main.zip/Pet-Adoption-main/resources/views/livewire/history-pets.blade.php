<div class="w-full py-12 dark:bg-gray-900">
    <div class="mx-auto sm:px-6 lg:px-8">
        {{-- BreadCramp --}}
        <div class="flex justify-between">
            <div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                        <li class="inline-flex items-center">
                            <a href="#"
                                class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                                <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                    fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                                </svg>
                                Pets
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="m1 9 4-4-4-4" />
                                </svg>
                                <a href="#"
                                    class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">History</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                {{-- <button type="button" onclick="window.location='{{ route('admin.pets.create') }}'"
                    class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                    Create New</button> --}}
            </div>
        </div>
        {{-- End BreadCramp --}}
        {{-- Card --}}
        <div class="flex justify-between">
            <!-- Card 1 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image1.jpg" alt="Card 1 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">total dogs</div>
                    <p class="text-gray-500 text-base uppercase text-bold">
                        {{ $dogCount }}
                    </p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image2.jpg" alt="Card 2 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Total cats</div>
                    <p class="text-gray-500 text-base text-bold uppercase">
                        {{ $catCount }}
                    </p>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image2.jpg" alt="Card 2 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Total Animals</div>
                    <p class="text-gray-500 text-base text-bold">
                        {{ $animalCount }}
                    </p>
                </div>
            </div>
        </div>
        {{-- Card End --}}

        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg dark:bg-gray-800">
            <div class="relative flex items-center justify-end p-4">
                <input wire:model="searchTerm" wire:keyup="updateSearch" type="search"
                    class="w-64 text-black px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"
                    placeholder="Search by Name">
            </div>

            {{-- Table --}}
            <div class="relative overflow-x-auto">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Image
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Slug
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Age
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Type
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody class="">
                        @foreach ($pets as $pet)
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <td class="px-6 py-4">
                                    @if ($pet->image === null)
                                        <img src="/images/noiage.png" alt="image"
                                            class="w-56 h-36 rounded-md object-cover">
                                    @else
                                        <img src="/storage/{{ $pet->image }}" alt="image"
                                            class="w-56 h-36 rounded-md object-cover">
                                    @endif
                                </td>
                                <td class="px-6 py-4">
                                    {{ $pet->name }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $pet->slug }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $pet->age }}
                                </td>
                                <td class="px-6 py-4 capitalize">
                                    {{ $pet->pet_type }}
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <div class="flex text-red-600 cursor-pointer">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                        </svg>
                                        <button onclick="confirmDeletion({{ $pet->id }}, '{{ $pet->name }}')"
                                            class="mr-4 ml-1 font-medium text-red-600 hover:underline">Delete</button>
                                    </div>
                                    <script>
                                        function editUser(userId) {
                                            @this.call('editUser', userId);
                                        }

                                        function confirmDeletion(userId, userName) {
                                            if (confirm('Are you sure you want to delete the user ' + userName + '?')) {
                                                @this.call('deleteUser', userId);
                                            }
                                        }
                                    </script>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="p-4">
                {{ $pets->links() }}
            </div>
            {{-- End of Table --}}
        </div>
    </div>
</div>
