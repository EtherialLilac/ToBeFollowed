<div>
    <section id="donate" class="bg-gray-50 dark:bg-gray-800">
        <div class="py-8 px-4 mx-auto max-w-screen-xl sm:py-16 lg:px-6">
            <div data-aos="fade-down" data-aos-duration="1000" class="mb-8 w-full lg:mb-16">
                <h2 class="mb-4 text-4xl font-extrabold text-gray-900 dark:text-white text-center">
                    Why Donate?
                </h2>
                <p class="text-gray-500 text-center sm:text-xl dark:text-gray-400">
                    GROWING COMPASSION <br>
                    <span>Through education and awareness drives, more and more and joining the cause.</span>
                </p>
                {{-- Modal --}}

                @if (!auth()->check())
                <div class="flex justify-center mt-4">
                    <!-- Modal toggle -->
                    <button onclick="window.location='{{ route('login') }}'"
                        class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="button">
                        Donate Now
                    </button>
                </div>    
                @else
                <div class="flex justify-center mt-4">
                    <!-- Modal toggle -->
                    <button data-modal-target="donate-modal" data-modal-toggle="donate-modal"
                        class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        type="button">
                        Donate Now
                    </button>
                </div>
                @endif

                <!-- Main modal -->
                <div id="donate-modal" tabindex="-1" aria-hidden="true"
                    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
                    <div class="relative p-4 w-full max-w-md max-h-full">
                        <!-- Modal content -->
                        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                            <!-- Modal header -->
                            <div
                                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                                    Amount
                                </h3>
                                <button type="button"
                                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm h-8 w-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                    data-modal-toggle="donate-modal">
                                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                        fill="none" viewBox="0 0 14 14">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                    </svg>
                                    <span class="sr-only">Close modal</span>
                                </button>
                            </div>
                            <!-- Modal body -->
                            <div class="p-4 md:p-5">
                                <p class="text-gray-500 dark:text-gray-400 mb-4">Select your desired amount:</p>
                                <ul class="space-y-4 mb-4">
                                    <li>
                                        <input type="radio" id="job-1" name="job" value="100"
                                            wire:model="selectedAmount" class="hidden peer" required>
                                        <label for="job-1"
                                            class="inline-flex items-center justify-between w-full p-5 text-gray-900 bg-white border border-gray-200 rounded-lg cursor-pointer dark:hover:text-gray-300 dark:border-gray-500 dark:peer-checked:text-blue-500 peer-checked:border-blue-600 peer-checked:text-blue-600 hover:text-gray-900 hover:bg-gray-100 dark:text-white dark:bg-gray-600 dark:hover:bg-gray-500">
                                            <div class="block">
                                                <div class="w-full text-lg font-semibold">100</div>

                                            </div>
                                            <svg class="w-4 h-4 ms-3 rtl:rotate-180 text-gray-500 dark:text-gray-400"
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                                viewBox="0 0 14 10">
                                                <path stroke="currentColor" stroke-linecap="round"
                                                    stroke-linejoin="round" stroke-width="2"
                                                    d="M1 5h12m0 0L9 1m4 4L9 9" />
                                            </svg>
                                        </label>
                                    </li>
                                    <li>
                                        <input type="radio" id="job-2" name="job" value="200"
                                            wire:model="selectedAmount" class="hidden peer">
                                        <label for="job-2"
                                            class="inline-flex items-center justify-between w-full p-5 text-gray-900 bg-white border border-gray-200 rounded-lg cursor-pointer dark:hover:text-gray-300 dark:border-gray-500 dark:peer-checked:text-blue-500 peer-checked:border-blue-600 peer-checked:text-blue-600 hover:text-gray-900 hover:bg-gray-100 dark:text-white dark:bg-gray-600 dark:hover:bg-gray-500">
                                            <div class="block">
                                                <div class="w-full text-lg font-semibold">200</div>
                                            </div>
                                            <svg class="w-4 h-4 ms-3 rtl:rotate-180 text-gray-500 dark:text-gray-400"
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                                viewBox="0 0 14 10">
                                                <path stroke="currentColor" stroke-linecap="round"
                                                    stroke-linejoin="round" stroke-width="2"
                                                    d="M1 5h12m0 0L9 1m4 4L9 9" />
                                            </svg>
                                        </label>
                                    </li>
                                    <li>
                                        <input type="radio" id="job-3" name="job" value="500"
                                            wire:model="selectedAmount" class="hidden peer">
                                        <label for="job-3"
                                            class="inline-flex items-center justify-between w-full p-5 text-gray-900 bg-white border border-gray-200 rounded-lg cursor-pointer dark:hover:text-gray-300 dark:border-gray-500 dark:peer-checked:text-blue-500 peer-checked:border-blue-600 peer-checked:text-blue-600 hover:text-gray-900 hover:bg-gray-100 dark:text-white dark:bg-gray-600 dark:hover:bg-gray-500">
                                            <div class="block">
                                                <div class="w-full text-lg font-semibold">500</div>
                                            </div>
                                            <svg class="w-4 h-4 ms-3 rtl:rotate-180 text-gray-500 dark:text-gray-400"
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                                viewBox="0 0 14 10">
                                                <path stroke="currentColor" stroke-linecap="round"
                                                    stroke-linejoin="round" stroke-width="2"
                                                    d="M1 5h12m0 0L9 1m4 4L9 9" />
                                            </svg>
                                        </label>
                                    </li>
                                    <li>
                                        <input type="radio" id="job-3" name="job" value="1000"
                                            wire:model="selectedAmount" class="hidden peer">
                                        <label for="job-3"
                                            class="inline-flex items-center justify-between w-full p-5 text-gray-900 bg-white border border-gray-200 rounded-lg cursor-pointer dark:hover:text-gray-300 dark:border-gray-500 dark:peer-checked:text-blue-500 peer-checked:border-blue-600 peer-checked:text-blue-600 hover:text-gray-900 hover:bg-gray-100 dark:text-white dark:bg-gray-600 dark:hover:bg-gray-500">
                                            <div class="block">
                                                <div class="w-full text-lg font-semibold">1000</div>
                                            </div>
                                            <svg class="w-4 h-4 ms-3 rtl:rotate-180 text-gray-500 dark:text-gray-400"
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                                viewBox="0 0 14 10">
                                                <path stroke="currentColor" stroke-linecap="round"
                                                    stroke-linejoin="round" stroke-width="2"
                                                    d="M1 5h12m0 0L9 1m4 4L9 9" />
                                            </svg>
                                        </label>
                                    </li>
                                </ul>
                                <button onclick="donateNow()"
                                    class="text-white inline-flex w-full justify-center bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                    Continue to Gcash
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    function donateNow() {
                        if (confirm('Are you sure you want to Continue')) {
                            @this.call('donate');
                        }
                    }
                </script>

                {{-- end of modal --}}
            </div>
            <div class="space-y-8 md:grid md:grid-cols-2 lg:grid-cols-3 md:gap-12 md:space-y-0">
                <div data-aos="fade-up" data-aos-duration="1000">
                    <div
                        class="flex justify-center items-center mb-4 w-10 h-10 rounded-full bg-blue-100 lg:h-12 lg:w-12 dark:bg-blue-900">
                        <i
                            class="fa fa-street-view text-[1.8rem] text-blue-500-600 lg:w-6 lg:h-6 dark:text-blue-500-300"></i>
                    </div>
                    <h3 class="mb-2 text-xl font-bold dark:text-white">
                        PET WISH LIST
                    </h3>
                    <p class="text-gray-500 dark:text-gray-400">
                        • Dog and Cat food (kibble and canned) <br>
                        • Crates, carriers or cages <br>
                        • Pet diapers and wee wee pads <br>
                        • Scratching posts for the cats <br>
                        • Chew toys for the dogs <br>
                        • Vaccines, medicine and vitamins <br>
                        • Dog and cat treats <br>
                        • Leashes, harnesses and collars
                    </p>
                </div>
                <div data-aos="fade-up" data-aos-duration="2000">
                    <div
                        class="flex justify-center items-center mb-4 w-10 h-10 rounded-full bg-blue-100 lg:h-12 lg:w-12 dark:bg-blue-900">
                        <i
                            class="fa fa-tasks text-[1.5rem] text-blue-500-600 lg:w-6 lg:h-6 dark:text-blue-500-300"></i>
                    </div>
                    <h3 class="mb-2 text-xl font-bold dark:text-white">
                        SHELTER WISH LIST
                    </h3>
                    <p class="text-gray-500 dark:text-gray-400">
                        • Detergent powder and bleach <br>
                        • Bath towels <br>
                        • Garbage bags (XXL) <br>
                        • Foot rugs or door mats <br>
                        • Clinic supplies (alcohol, cotton, etc.) <br>
                        • Old newspapers <br>
                        • Toilet paper <br>
                        • Mops and brooms
                    </p>
                </div>
                <div data-aos="fade-up" data-aos-duration="3000">
                    <div
                        class="flex justify-center items-center mb-4 w-10 h-10 rounded-full bg-blue-100 lg:h-12 lg:w-12 dark:bg-blue-900">
                        <i
                            class="fa fa-commenting text-[1.5rem] text-blue-500-600 lg:w-6 lg:h-6 dark:text-blue-500-300"></i>
                    </div>
                    <h3 class="mb-2 text-xl font-bold dark:text-white">
                        Branches
                    </h3>
                    <p class="text-gray-500 dark:text-gray-400">
                        • Cats of Ayala Technohub <br>
                        • Cats of Ayala Malls <br>
                        • Cats Around Town (Town Center, Alabang) <br>
                        • Cats of BGC <br>
                        • Cats of Legaspi Village <br>
                        &nbsp;&nbsp;&nbsp;<span class="text-blue-500 cursor-pointer hover:text-white">and
                            more...</span>
                    </p>
                </div>
            </div>
        </div>
    </section>
</div>
