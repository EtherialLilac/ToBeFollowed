<div class="flex flex-col w-full h-screen container mx-auto px-8">
    <div class="my-4">
        <ul class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            @foreach ($tags as $tag)
                <li>
                    <div class="flex items-center p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                        <input wire:model="selectedTags" wire:click="filterPets" id="checkbox-item-{{ $tag->id }}"
                            type="checkbox" value="{{ $tag->id }}"
                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                        <label for="checkbox-item-{{ $tag->id }}"
                            class="w-full ms-2 text-sm font-medium text-gray-900 rounded dark:text-gray-300">{{ $tag->name }}</label>
                    </div>
                </li>
            @endforeach
        </ul>
        <div class="my-4">
            <div class="flex items-center">
                <label for="petTypes" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white mr-4">Select
                    Type</label>
                <select id="petTypes" wire:model="selectedPetType" wire:change="filterPets" id="petType"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-1/4 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="">All</option>
                    <option value="dog">Dog</option>
                    <option value="cat">Cat</option>
                </select>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @foreach ($filteredPets as $pet)
            @if ($pet->is_active == 1)
                <div wire:key="{{ $pet->id }}"
                    class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                    @if ($pet->image == null)
                        <div>
                            <img class="rounded-t-lg h-48 w-full object-fill" src="/images/noiage.png" alt="" />
                        </div>
                    @else
                        <div>
                            <img class="rounded-t-lg h-48 w-full object-fill"
                                src="{{ asset('storage/' . $pet->image) }}" alt="" />
                        </div>
                    @endif
                    <div class="p-5">
                        <div class="flex flex-row justify-between">
                            <div>
                                <span>
                                    <h3 class="text-xl font-bold tracking-tight text-gray-900 dark:text-white">
                                        {{ $pet->name }}
                                    </h3>

                                </span>
                                <p class="font-normal text-gray-700 dark:text-gray-400">
                                    <span> Type: {{ $pet->pet_type }} <br>
                                        Age: {{ $pet->age }} <br>
                                        Breed: {{ $pet->breed }} <br>
                                        Match: {{ number_format($pet->percentage_match, 2) }}% <br>
                                        Status: {{ $pet->status }} <br>
                                    </span>
                                </p>
                            </div>
                            <div>
                                <p class="font-normal text-gray-700 dark:text-gray-400">Tags:<br>
                                    @if ($pet->tags)
                                        @foreach ($pet->tags as $tag)
                                            <span class="text-blue-600">{{ $tag->name }}</span><br>
                                        @endforeach
                                    @endif
                                </p>
                            </div>
                        </div>
                        @if (auth()->check())
                            <button onclick="adoptNow('{{ $pet->id }}')"
                                class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                Adopt Now
                                <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9" />
                                </svg>
                            </button>
                        @else
                            <button type="button" onclick="window.location='{{ route('login') }}'"
                                class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Adopt
                                Now
                            </button>
                        @endif
                    </div>
                </div>
            @endif
        @endforeach
    </div>

    @if (session('success') || session('error'))
        <div x-data="{ show: true }" x-init="setTimeout(() => { show = false; }, 10000)" x-show="show" x-transition:enter="ease-out duration-300"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0" x-transition:leave="ease-in duration-200"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2" class="fixed bottom-4 right-4 z-50">
            @if (session('success'))
                <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400"
                    role="alert">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400"
                    role="alert">
                    {{ session('error') }}
                </div>
            @endif
        </div>
    @endif

    <script>
        function adoptNow(petId) {
            @this.call('adopt', petId);
        }

        function confirmDeletion(userId, userName) {
            if (confirm('Are you sure you want to delete the user ' + userName + '?')) {
                @this.call('deleteUser', userId);
            }
        }
    </script>

    {{-- <div class="p-4 mx-2">
        {{ $filteredPets->links() }}
    </div> --}}

</div>
