<div class="w-full py-12 dark:bg-gray-900">
    <div class="mx-auto sm:px-6 lg:px-8">
        @if (session('success'))
            <div x-data="{ open: true }" x-show="open" id="alert-border-3"
                class="flex items-center p-4 mb-4 text-green-800 border-t-4 border-green-300 bg-green-50 dark:text-green-400 dark:bg-gray-800 dark:border-green-800"
                role="alert">
                <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor" viewBox="0 0 20 20">
                    <path stroke="green" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <div class="ms-3 text-sm font-medium">
                    {{ session('success') }}
                </div>
                <button @click="open = false"
                    class="ms-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-green-400 dark:hover:bg-gray-700"
                    aria-label="Close">
                    <span class="sr-only">Dismiss</span>
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="green" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                </button>
            </div>
        @endif

        @if (session('error'))
            <div x-data="{ open: true }" x-show="open" id="alert-border-3"
                class="flex items-center p-4 mb-4 text-red-800 border-t-4 border-red-300 bg-red-50 dark:text-red-400 dark:bg-gray-800 dark:border-red-800"
                role="alert">
                <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor" viewBox="0 0 20 20">
                    <path stroke="red" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                </svg>
                <div class="ms-3 text-sm font-medium">
                    {{ session('error') }}
                </div>
                <button @click="open = false"
                    class="ms-auto -mx-1.5 -my-1.5 bg-red-50 text-red-500 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 hover:bg-red-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-red-400 dark:hover:bg-gray-700"
                    aria-label="Close">
                    <span class="sr-only">Dismiss</span>
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="red" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                </button>
            </div>
        @endif

        {{-- BreadCramp --}}
        <div class="flex justify-between">
            <div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                        <li class="inline-flex items-center">
                            <a href="#"
                                class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                                <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                    fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                                </svg>
                                Request
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="m1 9 4-4-4-4" />
                                </svg>
                                <a href="#"
                                    class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Home</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                {{-- <button type="button" onclick="window.location='{{ route('admin.request.create') }}'"
                    class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                    Create New</button> --}}
            </div>
        </div>
        {{-- End BreadCramp --}}
        {{-- Card --}}
        <div class="flex justify-between">
            <!-- Card 1 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image1.jpg" alt="Card 1 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">total dogs</div>
                    <p class="text-gray-500 text-base uppercase text-bold">
                        {{ $dogCount }}
                    </p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image2.jpg" alt="Card 2 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Total cats</div>
                    <p class="text-gray-500 text-base text-bold uppercase">
                        {{ $catCount }}
                    </p>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image2.jpg" alt="Card 2 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Total Animals</div>
                    <p class="text-gray-500 text-base text-bold">
                        {{ $animalCount }}
                    </p>
                </div>
            </div>
        </div>
        {{-- Card End --}}

        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg dark:bg-gray-800">
            <div class="relative flex items-center justify-end p-4">
                <input wire:model="searchTerm" wire:keyup="updateSearch" type="search"
                    class="w-64 text-black px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"
                    placeholder="Search by Name">
            </div>

            {{-- Table --}}
            <div class="relative overflow-x-auto">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Image
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Slug
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Age
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Type
                            </th>
                            <th scope="col" class="px-6 py-3 flex justify-center">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($requests as $request)
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <td class="px-6 py-4">
                                    @if ($request->image === null)
                                        <img src="/images/noiage.png" alt="image"
                                            class="w-56 h-36 rounded-md object-cover">
                                    @else
                                        <img src="{{ asset('storage/' . $request->image) }}" alt="image"
                                            class="w-56 h-36 rounded-md object-cover">
                                    @endif
                                </td>
                                <td class="px-6 py-4">
                                    {{ $request->name }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $request->slug }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $request->age }}
                                </td>
                                <td class="px-6 py-4 capitalize">
                                    {{ $request->pet_type }}
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <div x-data="{ isOpen: false }">
                                        <div class="relative" x-on:click.away="isOpen = false">
                                            <button @click="isOpen = !isOpen">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                    class="w-6 h-6">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M12 6.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 12.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 18.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5Z" />
                                                </svg>
                                            </button>
                                            <div x-show="isOpen" class="absolute space-y-4 my-2 rounded shadow-md">
                                                <div class="flex text-emerald-300 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                        viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                        class="w-6 h-6">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M11.35 3.836c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m8.9-4.414c.376.023.75.05 1.124.08 1.131.094 1.976 1.057 1.976 2.192V16.5A2.25 2.25 0 0 1 18 18.75h-2.25m-7.5-10.5H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V18.75m-7.5-10.5h6.375c.621 0 1.125.504 1.125 1.125v9.375m-8.25-3 1.5 1.5 3-3.75" />
                                                    </svg>
                                                    <button onclick="approve({{ $request->id }})"
                                                        class="mr-4 ml-1 font-medium text-emerald-300 hover:underline">Approve</button>
                                                </div>
                                                {{-- <div class="flex text-yellow-300 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                        viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                        class="w-6 h-6">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
                                                    </svg>
                                                    <button onclick="editUser({{ $request->id }})"
                                                        class="mr-4 ml-1 font-medium text-yellow-300 hover:underline">Edit</button>
                                                </div> --}}
                                                <div class="flex text-red-600 cursor-pointer">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                        viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                        class="w-6 h-6">
                                                        <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                                    </svg>
                                                    <button
                                                        onclick="confirmDeletion({{ $request->id }}, '{{ $request->name }}')"
                                                        class="mr-4 ml-1 font-medium text-red-600 hover:underline">Reject</button>

                                                    <script>
                                                        function approve(requestId) {
                                                            if (confirm('Confirmation for your action in Request')) {
                                                                @this.call('approveRequest', requestId);
                                                            }
                                                        }

                                                        function editUser(userId) {
                                                            @this.call('editUser', userId);
                                                        }

                                                        function confirmDeletion(userId, userName) {
                                                            if (confirm('Are you sure you want to delete the user ' + userName + '?')) {
                                                                @this.call('deleteUser', userId);
                                                            }
                                                        }
                                                    </script>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Main modal -->
                                    <div id="view-modal{{ $request->id }}" tabindex="-1" aria-hidden="true"
                                        class="text-left hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
                                        <div class="relative p-4 w-full max-w-2xl max-h-full">
                                            <!-- Modal content -->
                                            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                                                <!-- Modal header -->
                                                <div
                                                    class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                                        Users Information
                                                    </h3>
                                                    <button type="button"
                                                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                                        data-modal-hide="view-modal{{ $request->id }}">
                                                        <svg class="w-3 h-3" aria-hidden="true"
                                                            xmlns="http://www.w3.org/2000/svg" fill="none"
                                                            viewBox="0 0 14 14">
                                                            <path stroke="currentColor" stroke-linecap="round"
                                                                stroke-linejoin="round" stroke-width="2"
                                                                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                                        </svg>
                                                        <span class="sr-only">Close modal</span>
                                                    </button>
                                                </div>
                                                <!-- Modal body -->
                                                <div class="p-4 md:p-5 space-y-4">
                                                    <div class="grid gap-6 md:grid-cols-2">
                                                        <div>
                                                            <label for="first_name"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Full
                                                                name</label>
                                                            <input type="text" id="first_name"
                                                                value="{{ $request->name }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="email"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Slug</label>
                                                            <input type="email" id="email"
                                                                value="{{ $request->slug }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="age"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Age</label>
                                                            <input type="text" id="age"
                                                                value="{{ $request->age }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="type"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Type</label>
                                                            <input type="text" id="type"
                                                                value="{{ $request->pet_type }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="guardian"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Guardian
                                                                name</label>
                                                            <input type="text" id="guardian"
                                                                value="{{ $request->guardian }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="contact"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Contact</label>
                                                            <input type="text" id="contact"
                                                                value="{{ $request->contact }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="status"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Status</label>
                                                            <input type="text" id="status"
                                                                value="{{ $request->status }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>
                                                        <div>
                                                            <label for="is_active"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Visibility</label>
                                                            <input type="text" id="is_active"
                                                                value="{{ $request->is_active == 1 ? 'Yes' : 'No' }}"
                                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="" disabled>
                                                        </div>

                                                        <div>
                                                            <label for="document"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Document</label>
                                                            @if ($request->document === null)
                                                                <img src="/images/noiage.png" alt="image"
                                                                    class="w-56 h-36 rounded-md object-cover">
                                                            @else
                                                                <a
                                                                    href="{{ asset('storage/' . $request->document) }}">
                                                                    <img src="{{ asset('storage/' . $request->image) }}"
                                                                        alt="image"
                                                                        class="w-56 h-36 rounded-md object-cover">
                                                                </a>
                                                            @endif
                                                        </div>
                                                        <div>
                                                            <label for="message"
                                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                                            <textarea id="message" rows="4"
                                                                class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                                placeholder="Write your thoughts here..." disabled>{{ $request->description }}</textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Modal footer -->
                                                <div
                                                    class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                                                    {{-- <button data-modal-hide="view-modal" type="button"
                                                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">I
                                                        accept</button> --}}
                                                    <button data-modal-hide="view-modal{{ $request->id }}"
                                                        type="button"
                                                        class=" text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {{-- End of Modal --}}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="p-4">
                {{ $requests->links() }}
            </div>
            {{-- End of Table --}}
        </div>
    </div>
</div>
