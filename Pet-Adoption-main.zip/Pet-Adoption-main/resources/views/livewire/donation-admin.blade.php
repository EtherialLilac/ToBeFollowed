<div class="w-full py-12 dark:bg-gray-900">
    <div class="mx-auto sm:px-6 lg:px-8">
        {{-- BreadCramp --}}
        <div class="flex justify-between">
            <div>
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                        <li class="inline-flex items-center">
                            <a href="#"
                                class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                                <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                    fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                                </svg>
                                Donation
                            </a>
                        </li>
                        <li>
                            <div class="flex items-center">
                                <svg class="rtl:rotate-180 w-3 h-3 text-gray-400 mx-1" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="m1 9 4-4-4-4" />
                                </svg>
                                <a href="#"
                                    class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Home</a>
                            </div>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <button type="button" onclick="window.location='{{ route('admin.donation.create') }}'"
                    class="text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                    Create New</button>
            </div>
        </div>
        {{-- End BreadCramp --}}
        {{-- Card --}}
        <div class="flex justify-between">
            <!-- Card 1 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image1.jpg" alt="Card 1 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Users Donate</div>
                    <p class="text-gray-500 text-base uppercase text-bold">
                        {{ $donationCount }}
                    </p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="flex-1 w-full rounded overflow-hidden shadow-lg m-4">
                {{-- <img class="w-full" src="image2.jpg" alt="Card 2 Image"> --}}
                <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2 dark:text-white uppercase">Total Donations</div>
                    <p class="text-gray-500 text-base text-bold uppercase">
                        ₱ {{ number_format($totalDonation, 2) }}
                    </p>
                </div>
            </div>
        </div>
        {{-- Card End --}}

        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg dark:bg-gray-800">
            <div class="relative flex items-center justify-end p-4">
                <input wire:model="searchTerm" wire:keyup="updateSearch" type="search"
                    class="w-64 text-black px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"
                    placeholder="Search by Name">
            </div>

            {{-- Table --}}
            <div class="relative overflow-x-auto">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Email
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Amount
                            </th>
                            <th scope="col" class="px-6 py-3 text-center">
                                Payment Type
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <th scope="row"
                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    {{ $user->name }}
                                </th>
                                <td class="px-6 py-4">
                                    {{ $user->email }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $user->amount }}
                                </td>
                                <td class="px-6 py-4 text-center capitalize">
                                    {{ $user->payment_method }}
                                </td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="p-4">
                {{ $users->links() }}
            </div>
            {{-- End of Table --}}
        </div>
    </div>
</div>
