<div class="py-8 container px-6 mx-auto">

    <!-- Section: Design Block -->
    <section id="intake" class="background-radial-gradient">
        <style>
            .background-radial-gradient {
                background-color: hsl(218, 41%, 15%);
                background-image: radial-gradient(650px circle at 0% 0%,
                        hsl(218, 41%, 35%) 15%,
                        hsl(218, 41%, 30%) 35%,
                        hsl(218, 41%, 20%) 75%,
                        hsl(218, 41%, 19%) 80%,
                        transparent 100%),
                    radial-gradient(1250px circle at 100% 100%,
                        hsl(218, 41%, 45%) 15%,
                        hsl(218, 41%, 30%) 35%,
                        hsl(218, 41%, 20%) 75%,
                        hsl(218, 41%, 19%) 80%,
                        transparent 100%);
            }
        </style>

        <div class="px-6 py-6 md:px-6 text-center lg:text-left gray-800">
            <div class="container mx-auto xl:px-32">
                <div class="grid lg:grid-cols-2 gap-12 items-center">
                    <div class="mt-12 lg:mt-0">
                        <div class="p-4 md:p-5 space-y-4">
                            <form wire:submit.prevent="create" enctype="multipart/form-data" method="POST"
                                class="border border-gray-600 p-4 rounded">
                                <div class="grid gap-6 mb-6 md:grid-cols-2">
                                    <div>
                                        <label for="pet_name"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pet
                                            Name</label>
                                        <input type="text" id="pet name" wire:model="petName"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="Name" required>
                                    </div>
                                    <div>
                                        <label for="slug"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Slug</label>
                                        <input type="text" id="slug" wire:model="slug"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="slug" required>
                                    </div>
                                    <div>
                                        <label for="pet_age"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pet
                                            Age</label>
                                        <input type="text" id="pet age" wire:model="petAge"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="Age" required>
                                    </div>
                                    <div>
                                        <label for="pet"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select
                                            Type</label>
                                        <select id="pet" wire:model="petType"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            <option class="text-black" selected>Choose a Pet Type</option>
                                            <option value="dog" class="my-1 text-md text-black">Dog</option>
                                            <option value="cat" class="my-1 text-md text-black">Cat</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="breed"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pet
                                            Breed</label>
                                        <input type="text" id="breed" wire:model="petBreed" name="petBreed"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="Breed" required>
                                    </div>
                                    {{-- File input  --}}
                                    <div>
                                        <label
                                            class="block mb-2
                                        text-sm font-medium text-gray-900 dark:text-white"
                                            for="file_input">Pet Image</label>
                                        <input
                                            class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400"
                                            id="file_input" type="file" wire:model="fileInput" required>
                                    </div>
                                    <div>
                                        <label for="Guardian name"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Guardian
                                            Name</label>
                                        <input type="text" id="Guardian name" wire:model="guardianName"
                                            class="mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="Name" required>
                                    </div>
                                    {{-- File input  --}}
                                    <div>
                                        <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            for="document">Valid ID</label>
                                        <input
                                            class="mb-2 block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400"
                                            id="file_input" type="file" wire:model="document" required>
                                    </div>

                                    <div>
                                        <label for="email"
                                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Guardian
                                            Email</label>
                                        <input type="email" id="email" wire:model="email"
                                            class="mb-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                            placeholder="email" required>
                                    </div>
                                    <div>
                                        <div>
                                            <label for="Guardian Contact"
                                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Guardian
                                                Contact</label>
                                            <input type="text" id="Guardian Contact" wire:model="guardianContact"
                                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                                placeholder="Contact" required>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <label for="message"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Pet
                                        Characteristics</label>
                                    <textarea id="message" rows="4" id="description" wire:model="description"
                                        class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                        placeholder="Pet Characteristics list here"></textarea>
                                </div>
                                <div class="mt-2">
                                    <button type="submit"
                                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="mb-12 lg:mb-0">
                        <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706786531/dog-nose-istock-uc-santa-barbara-small_0_dj33al.jpg"
                            class="w-full rounded-lg shadow-lg h-94" alt="" />
                        {{-- Message --}}
                        @if (session()->has('success'))
                            <div x-data="{ isOpen: true }" x-init="setTimeout(() => isOpen = false, 10000)" x-show="isOpen" id="alert-border-3"
                                class="mt-4 flex items-center p-4 mb-4 text-green-800 border-t-4 border-green-300 bg-green-50 dark:text-green-400 dark:bg-gray-800 dark:border-green-800"
                                role="alert">
                                <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
                                </svg>
                                <div class="ms-3 text-sm font-medium">
                                    {{ session('success') }}
                                </div>
                                <button type="button"
                                    class="ms-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-green-400 dark:hover:bg-gray-700"
                                    data-dismiss-target="#alert-border-3" aria-label="Close">
                                    <span class="sr-only">Dismiss</span>
                                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                        fill="none" viewBox="0 0 14 14">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                    </svg>
                                </button>
                            </div>
                        @endif
                        {{-- End message --}}
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
