<x-app-layout>
    <section id="home" class="bg-white dark:bg-gray-900">
        <div class="grid py-20 px-4 mx-auto max-w-screen-xl lg:gap-8 xl:gap-0 lg:py-[8.4rem] lg:grid-cols-12">
            <div data-aos="fade-right" data-aos-duration="1000" class="place-self-center mr-auto lg:col-span-7">
                <h1 class="mb-4 max-w-2xl text-4xl font-extrabold leading-none md:text-5xl xl:text-6xl dark:text-white">
                    PawSome Match
                </h1>
                <p class="mb-6 max-w-2xl font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl dark:text-gray-400">
                    Cats of Newport
                </p>
                <a href="#adopt"
                    class="inline-flex justify-center items-center py-3 px-5 mr-3 text-base font-medium text-center text-white rounded-lg bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-500-300 dark:focus:ring-blue-500-900">
                    ADOPT YOUT PET
                    <i class="fa fa-arrow-right ml-2 -mr-1 text-[1.1rem]"></i>
                </a>
            </div>
            <div class="hidden lg:mt-0 lg:col-span-5 lg:flex h-[32rem]">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2 rounded py-1 px-5">
                    <div data-aos="fade-left" data-aos-duration="1000" class="container auto">
                        <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706785169/Pets-1-1200x800_nre0ej.jpg"
                            alt="" class="rounded h-40 w-full object-cover sm:h-56 md:h-full skew-y-6" />
                    </div>
                    <div data-aos="fade-left" data-aos-duration="2000"
                        class="grid grid-cols-2 gap-4 md:grid-cols-1 lg:grid-cols-2">
                        <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706786669/121423_mr_cat_fetch_feat_oam4ax.jpg"
                            alt="" class="rounded h-40 w-full object-cover sm:h-56 md:h-full skew-y-6" />

                        <img src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706786532/domestic-dog_thumb_3x4_g72mdq.jpg"
                            alt=""
                            class="rounded h-40 w-full object-cover object-right sm:h-56 md:h-full skew-y-6" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- services -->
    <livewire-api-donation />
    <!-- services end -->

    <!-- about start -->
    <section id="about" class="bg-white dark:bg-gray-900">
        <br><br>
        <h2 data-aos="fade-down" data-aos-duration="1000"
            class="mt-4 mb-8 text-4xl font-extrabold text-gray-900 text-center dark:text-white ">
            About
        </h2>
        <div class="gap-16 items-center py-0 px-4 mx-auto max-w-screen-xl lg:grid lg:grid-cols-2 lg:pb-16 lg:px-6">
            <div data-aos="fade-right" data-aos-duration="1000"
                class="font-light text-gray-500 sm:text-lg dark:text-gray-400">
                <p class="mb-2 text-2xl font-extrabold text-gray-900 dark:text-white">
                    INTRODUCTION
                    </h2>
                <p class="mb-2">
                    Cats of Newport City was founded in 2021 at the height of the pandemic. Prior to founding the
                    group,
                    I was already an active animal welfare advocate and volunteer for the country’s biggest animal
                    welfare organization, Pawssion Project, since 2018. Cats of Newport City is not a shelter. <a
                        class="text-blue-500" href="{{ asset('attachments/NewportCity_Introduction.pdf') }}"
                        download="{{ asset('attachments/NewportCity_Introduction.pdf') }}">Learn more...</a>
                </p>
                <p class="mb-2 text-2xl font-extrabold text-gray-900 dark:text-white">EFFORTS AND PARTNERS</p>
                <p class="mb-2">
                    <strong> Partners: CARA Welfare Philippines and Pawssion Project</strong>

                    Newport City: Caught-Spayed/Neutered-Vaccinated-Returned to date: 116 cats Adoptions to date: 97
                    Newport City cats <a class="text-blue-500"
                        href="{{ asset('attachments/Newport_City_Precautions.pdf') }}"
                        download="{{ asset('attachments/Newport_City_Precautions.pdf') }}">Learn more...</a>
                </p>
                <p class="mb-2 text-2xl font-extrabold text-gray-900 dark:text-white">PRE-CAUTIONS</p>
                <p>
                    CAT ADVOCACY SIGNAGES <a class="text-blue-500"
                        href="{{ asset('attachments/NewportCity_Activities.pdf') }}"
                        download="{{ asset('attachments/NewportCity_Activities.pdf') }}">Learn more...</a>
                </p>
            </div>
            <div data-aos="fade-down" data-aos-duration="1000" class="grid grid-cols-2 gap-4 mt-8">
                <img class="w-full rounded-lg"
                    src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706786531/dog-nose-istock-uc-santa-barbara-small_0_dj33al.jpg"
                    alt="office content 1" />
                <img class="mt-4 w-full rounded-lg lg:mt-10"
                    src="https://res.cloudinary.com/drcyxqm6p/image/upload/v1706786531/dog-nose-istock-uc-santa-barbara-small_0_dj33al.jpg"
                    alt="office content 2" />
            </div>
        </div>
    </section>
    <!-- about end -->

    <section class="bg-gray-50 dark:bg-gray-800">
        <div data-aos="fade-dowm" data-aos-duration="2000" class="py-8 px-4 mx-auto max-w-screen-xl lg:py-16 lg:px-6">
            <div class="max-w-screen-lg text-gray-500 sm:text-lg  dark:text-gray-400">
                <h2 class="mb-4 text-4xl font-bold text-gray-900  dark:text-white">
                    The goals of Cats of Newport
                    City are to:
                    <span class="font-extrabold">Fed all Rescued Animal</span>.
                </h2>
                <p class="mb-4 font-light">
                    (1) Encourage compassion and peaceful co-existence with our community cats;
                </p>
                <p class="mb-4 font-light">
                    (2) Promote catch-spay/neuter-vaccinate-return (CNVR) efforts to humanely control the growing stray
                    cat population in the community;
                </p>
                <p class="mb-4 font-light">
                    (3) Educate the township on activities that will help support the wellbeing of our community cats :
                    fostering, rehabilitation, and when possible, adoption.
                </p>
            </div>
        </div>
    </section>

    <!-- ====== FAQ Section Start -->
    <section class="bg-gray-50 dark:bg-gray-800" id="faq" x-data="{ openFaq1: false, openFaq2: false, openFaq3: false, openFaq4: false, openFaq5: false, openFaq6: false }"
        class="relative z-20 overflow-hidden bg-white pt-20 pb-12 lg:pt-[30px] lg:pb-[90px]">
        <div class="container mx-auto px-12">
            <div class="-mx-4 flex flex-wrap">
                <div class="w-full px-4">
                    <div data-aos="fade-up" data-aos-duration="1000"
                        class="mx-auto mb-[60px] max-w-[520px] text-center lg:mb-20">
                        <span class="mb-2 block text-lg font-semibold text-blue-500 dark:text-white">
                            FAQ
                        </span>
                        <h2 class="mb-4 text-3xl font-bold text-dark sm:text-4xl md:text-[40px] dark:text-white">
                            Any Questions? Look Here
                        </h2>
                    </div>
                </div>
            </div>
            <div class="-mx-4 flex flex-wrap">
                <div class="w-full px-4 lg:w-1/2">
                    <div data-aos="fade-right" data-aos-duration="1000"
                        class="single-faq mb-8 w-full rounded-lg border border-[#7c7d83] bg-slate-400 p-4 sm:p-8 lg:px-6 xl:px-8">
                        <button class="faq-btn flex w-full text-left" @click="openFaq1 = !openFaq1">
                            <div
                                class="mr-5 flex h-10 w-full max-w-[40px] items-center justify-center rounded-lg bg-blue-500 bg-opacity-5 text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>

                            </div>
                            <div class="w-full">
                                <h4 class="text-lg font-semibold text-black mb-7">
                                    How to adopt?
                                </h4>
                            </div>
                        </button>
                        <div x-show="openFaq1" class="faq-content pl-[62px]">
                            <p class="py-3 text-base leading-relaxed text-body-color">
                                - Click your desired characteristics of your pet.. <br>
                                - the system will automatically match and filter your preferences by percentage.. <br>
                                - by submitting the form an email will be sent for confirmation..<br>
                                - wait for an update if you are eligible to adopt your desired pet.

                            </p>
                        </div>
                    </div>

                    <div data-aos="fade-right" data-aos-duration="2000"
                        class="single-faq mb-8 w-full rounded-lg border border-[#7c7d83] bg-slate-400 p-4 sm:p-8 lg:px-6 xl:px-8">
                        <button class="faq-btn flex w-full text-left" @click="openFaq3 = !openFaq3">
                            <div
                                class="mr-5 flex h-10 w-full max-w-[40px] items-center justify-center rounded-lg bg-blue-500 bg-opacity-5 text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>

                            </div>
                            <div class="w-full">
                                <h4 class="text-lg font-semibold text-black">
                                    Does adopting pet requires payment?
                                </h4>
                            </div>
                        </button>
                        <div x-show="openFaq3" class="faq-content pl-[62px]">
                            <p class="py-3 text-base leading-relaxed text-body-color">
                                No, cats of newport city is a free adopting organization.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="w-full px-4 lg:w-1/2">
                    <div data-aos="fade-left" data-aos-duration="1000"
                        class="single-faq mb-8 w-full rounded-lg border border-[#7c7d83] bg-slate-400 p-4 sm:p-8 lg:px-6 xl:px-8">
                        <button class="faq-btn flex w-full text-left" @click="openFaq4 = !openFaq4">
                            <div
                                class="mr-5 flex h-10 w-full max-w-[40px] items-center justify-center rounded-lg bg-blue-500 bg-opacity-5 text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>

                            </div>
                            <div class="w-full">
                                <h4 class="text-lg font-semibold text-black">
                                    What if I want to donate some goods and deliver it to your location?
                                </h4>
                            </div>
                        </button>
                        <div x-show="openFaq4" class="faq-content pl-[62px]">
                            <p class="py-3 text-base leading-relaxed text-body-color">
                                Donators can deliver at Newport city, Pasay
                            </p>
                        </div>
                    </div>
                    <div data-aos="fade-left" data-aos-duration="2000"
                        class="single-faq mb-8 w-full rounded-lg border border-[#7c7d83] bg-slate-400 p-4 sm:p-8 lg:px-6 xl:px-8">
                        <button class="faq-btn flex w-full text-left" @click="openFaq5 = !openFaq5">
                            <div
                                class="mr-5 flex h-10 w-full max-w-[40px] items-center justify-center rounded-lg bg-blue-500 bg-opacity-5 text-blue-500">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>

                            </div>
                            <div class="w-full">
                                <h4 class="text-lg font-semibold text-black">
                                    How can I donate cash?
                                </h4>
                            </div>
                        </button>
                        <div x-show="openFaq5" class="faq-content pl-[62px]">
                            <p class="py-3 text-base leading-relaxed text-body-color">
                                You can donate VIA Gcash no. 09173260175 and by iteracting with the admins on the
                                chatbox.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="adopt" class="bg-white dark:bg-gray-900 p-4">
        <div class="py-8 px-4 mx-auto max-w-screen-xl sm:py-16 lg:px-6">
            <div data-aos="fade-up" data-aos-duration="2000" class="mx-auto max-w-screen-sm text-center">
                <h2 class="mb-4 text-4xl font-extrabold leading-tight text-gray-900 dark:text-white">
                    Adopt
                </h2>
                <p class="mb-6 font-light text-gray-500 dark:text-gray-400 md:text-lg">
                    Adopting a dog is not just about bringing a pet into your home; it's a transformative experience
                    that enriches your life in countless ways. When you choose to adopt a dog, you're not only gaining a
                    loyal companion but also opening your heart to unconditional love, joy, and boundless affection.
                </p>
            </div>
        </div>
    </section>
    {{-- Message --}}
    @if (session()->has('success'))
        <div x-data="{ isOpen: true }" x-init="setTimeout(() => isOpen = false, 3000)" x-show="isOpen" id="alert-border-3"
            class="flex items-center p-4 mb-4 text-green-800 border-t-4 border-green-300 bg-green-50 dark:text-green-400 dark:bg-gray-800 dark:border-green-800"
            role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                fill="currentColor" viewBox="0 0 20 20">
                <path
                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <div class="ms-3 text-sm font-medium">
                {{ session('success') }}
            </div>
            <button type="button"
                class="ms-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-green-400 dark:hover:bg-gray-700"
                data-dismiss-target="#alert-border-3" aria-label="Close">
                <span class="sr-only">Dismiss</span>
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                </svg>
            </button>
        </div>
    @endif
    {{-- End message --}}
    @livewire('footer')
</x-app-layout>
