<x-admin-layout>
    <livewire-donation-admin />
</x-admin-layout>
