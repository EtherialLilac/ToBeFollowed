<x-admin-layout>
    <livewire-create-donation />
</x-admin-layout>
