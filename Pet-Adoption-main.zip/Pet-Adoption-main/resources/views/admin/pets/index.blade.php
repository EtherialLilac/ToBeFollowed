<x-admin-layout>
    <livewire-pets-admin />
</x-admin-layout>
