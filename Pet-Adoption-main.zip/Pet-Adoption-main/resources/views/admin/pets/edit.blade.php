@php
    $id = request()->route('id');
@endphp

<x-admin-layout>
    <livewire:edit-pets-admin :petId="$id" />
</x-admin-layout>
