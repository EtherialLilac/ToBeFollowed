<x-admin-layout>
    <livewire-history-pets/>
</x-admin-layout>
