<x-admin-layout>
    <livewire-create-pets-admin/>
</x-admin-layout>