<x-admin-layout>
    <livewire-tag-admin />
</x-admin-layout>
