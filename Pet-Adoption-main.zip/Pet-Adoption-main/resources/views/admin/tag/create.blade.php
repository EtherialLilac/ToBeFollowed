<x-admin-layout>
    <livewire-create-tag-admin />
</x-admin-layout>
