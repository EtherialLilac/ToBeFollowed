<x-admin-layout>
    <livewire-create-users-admin/>
</x-admin-layout>