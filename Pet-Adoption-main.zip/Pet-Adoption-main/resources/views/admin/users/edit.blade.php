@php
    $id = request()->route('id');
@endphp

<x-admin-layout>
    <livewire:edit-users-admin :userId="$id" />
</x-admin-layout>
