@php
    $id = request()->route('id');
@endphp

<x-admin-layout>
    <livewire:edit-request-admin :petId="$id" />
</x-admin-layout>
