<x-admin-layout>
    <livewire-create-request-admin/>
</x-admin-layout>