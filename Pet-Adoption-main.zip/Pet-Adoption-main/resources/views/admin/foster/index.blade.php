<x-admin-layout>
    <livewire-request-admin />
</x-admin-layout>
