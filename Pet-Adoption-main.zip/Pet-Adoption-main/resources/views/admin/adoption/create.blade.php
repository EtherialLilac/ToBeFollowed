<x-admin-layout>
    <livewire-create-adopts-admin />
</x-admin-layout>
