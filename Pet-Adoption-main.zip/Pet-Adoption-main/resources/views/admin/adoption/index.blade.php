<x-admin-layout>
    <livewire-adopts-admin />
</x-admin-layout>
