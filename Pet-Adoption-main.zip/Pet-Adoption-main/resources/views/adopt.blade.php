<x-app-layout>
    <livewire-adopt-modal />
</x-app-layout>