<?php

use App\Livewire\AdoptModal;
use App\Livewire\ApiDonation;
use App\Livewire\Intake;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('intakeAndFoster', Intake::class)->name('intake.foster');
Route::get('Adopt/animal', AdoptModal::class)->name('adopt.modal');

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::middleware(['auth'])->group(function () {
        // Route::get('/admin', function () {
        //     if (auth()->check() && auth()->user()->isAdmin == 1) {
        //         return view('admin.donation.index');
        //     } else {
        //         abort(403);
        //     }
        // })->name('admin.donation.index');
        

        /******************************************************** Adopted History Pet *************************************************************/

        Route::get('/history', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.pets.history');
            } else {
                abort(403);
            }
        })->name('admin.pets.history');

        /******************************************************** Tag *************************************************************/

        Route::get('/tag', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.tag.index');
            } else {
                abort(403);
            }
        })->name('admin.tag.index');
        // Adopt Create
        Route::get('/tag/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.tag.create');
            } else {
                abort(403);
            }
        })->name('admin.tag.create');
        // Adopt Edit
        Route::get('/tag/edit/{id}', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.tag.edit');
            } else {
                abort(403);
            }
        })->name('admin.tag.edit');

        /******************************************************** Donation *************************************************************/

        Route::get('/donation', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.donation.index');
            } else {
                abort(403);
            }
        })->name('admin.donation.index');

        Route::get('/donation/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.donation.create');
            } else {
                abort(403);
            }
        })->name('admin.donation.create');

        Route::get('/payment-success', [ApiDonation::class, 'onSuccess'])->name('payment.success');
        Route::get('/payment-cancel', [ApiDonation::class, 'onError'])->name('payment.cancel');

        /******************************************************** ADOPTION *************************************************************/

        // Adopt
        Route::get('/adoption', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.adoption.index');
            } else {
                abort(403);
            }
        })->name('admin.adopt.index');
        // Adopt Create
        Route::get('/adopt/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.adoption.create');
            } else {
                abort(403);
            }
        })->name('admin.adopt.create');
        // Adopt Edit
        Route::get('/adopt/edit/{id}', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.adoption.edit');
            } else {
                abort(403);
            }
        })->name('admin.adopt.edit');


        /******************************************************** REQUEST *************************************************************/

        // Request
        Route::get('/request', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.foster.index');
            } else {
                abort(403);
            }
        })->name('admin.request.index');
        // Request Create
        Route::get('/request/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.foster.create');
            } else {
                abort(403);
            }
        })->name('admin.request.create');
        // Request Edit
        Route::get('/request/edit/{id}', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.foster.edit');
            } else {
                abort(403);
            }
        })->name('admin.request.edit');


        /******************************************************** USERS *************************************************************/

        // Users
        Route::get('/users', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.users.index');
            } else {
                abort(403);
            }
        })->name('admin.users.index');
        // Users Create
        Route::get('/users/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.users.create');
            } else {
                abort(403);
            }
        })->name('admin.users.create');
        // Users Edit
        Route::get('/users/edit/{id}', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.users.edit');
            } else {
                abort(403);
            }
        })->name('admin.users.edit');

        /******************************************************** PETS *************************************************************/

        // Pets
        Route::get('/pets', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.pets.index');
            } else {
                abort(403);
            }
        })->name('admin.pets.index');
        // Pets Create
        Route::get('/pets/create', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.pets.create');
            } else {
                abort(403);
            }
        })->name('admin.pets.create');
        // Pets Edit
        Route::get('/pets/edit/{id}', function () {
            if (auth()->check() && auth()->user()->isAdmin == 1) {
                return view('admin.pets.edit');
            } else {
                abort(403);
            }
        })->name('admin.pets.edit');
    });
});
