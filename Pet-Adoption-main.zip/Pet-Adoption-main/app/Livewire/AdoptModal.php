<?php

namespace App\Livewire;

use App\Models\Pet;
use App\Models\Tag;
use Livewire\Component;
use Livewire\WithPagination;
use App\Mail\AdoptionRequest;
use Illuminate\Support\Facades\Mail;

class AdoptModal extends Component
{
    use WithPagination;

    public $selectedTags = [];
    public $selectedPetType = null;
    public $selectedPetId;
    public $isOpen = false;
    public $percentageMatches = [];

    public function adopt($petId)
    {
        $pet = Pet::findOrFail($petId);

        $pet->update(['status' => 'pending']);
        
        // Create an adopt record for the pet
        $adoption = $pet->adopts()->create([
            'adopt_name' => auth()->user()->name,
            'adopt_email' => auth()->user()->email,
            'adopt_contact' => auth()->user()->contact,
            'status' => 'pending',
        ]);

        // $user = auth()->user();
        // Mail::to($user->email)->send(new AdoptionRequest($adoption, $pet));

        session()->flash('success', 'Adoption request submitted successfully. Please check your email!');

        return redirect()->route('adopt.modal');
    }

    public function render()
    {
        $tags = Tag::where('is_active', 1)->get();
        $filteredPets = $this->getFilteredPets();

        return view('livewire.adopt-modal', compact('tags', 'filteredPets'));
    }

    public function filterPets()
    {
        $this->resetPage();
    }

    private function getFilteredPets()
    {
        $query = Pet::with('tags');

        // Check if only pet type is selected
        if ($this->selectedPetType && empty($this->selectedTags)) {
            $query->where('pet_type', $this->selectedPetType);
        }

        // Check if only tags are selected
        if (!empty($this->selectedTags) && !$this->selectedPetType) {
            $query->whereHas('tags', function ($tagsQuery) {
                $tagsQuery->whereIn('tags.id', $this->selectedTags);
            });
        }

        // Check if both pet type and tags are selected
        if ($this->selectedPetType && !empty($this->selectedTags)) {
            $query->where('pet_type', $this->selectedPetType)
                ->whereHas('tags', function ($tagsQuery) {
                    $tagsQuery->whereIn('tags.id', $this->selectedTags);
                });
        }

        $filteredPets = $query->paginate(8);

        // Calculate percentage match for each pet
        $filteredPets->each(function ($pet) {
            $matchingTags = $pet->tags->pluck('id')->intersect($this->selectedTags)->count();
            $totalSelectedTags = count($this->selectedTags);

            // Check if all selected tags are present in the pet's tags
            $allTagsMatched = $matchingTags === $totalSelectedTags;

            $percentageMatch = $allTagsMatched ? 100 : ($matchingTags / $totalSelectedTags) * 100;
            $pet->percentage_match = $percentageMatch;
        });

        // Sort the pets based on percentage match in descending order
        $filteredPets = $filteredPets->sortByDesc('percentage_match')->values();

        return $filteredPets;
    }
}
