<?php

namespace App\Livewire;

use App\Models\Pet;
use App\Models\Request;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Mail;
use App\Mail\rejectRequestNotification;
use App\Mail\approveRequestNotification;
use Illuminate\Support\Facades\Redirect;

class RequestAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $animalCount;
    public $dogCount;
    public $document;
    public $catCount;
    public $searchTerm = '';

    public function approveRequest($requestId)
    {
        $adoption = Request::find($requestId);

        if ($adoption) {
            // Create a new record in the Pet table
            $pet = Pet::create([
                'name' => $adoption->name,
                'slug' => $adoption->slug,
                'age' => $adoption->age,
                'image' => $adoption->image,
                'breed' => $adoption->breed,
                'pet_type' => $adoption->pet_type,
                'guardian' => $adoption->guardian,
                'guardian_email' => $adoption->guardian_email,
                'contact' => $adoption->contact,
                'description' => $adoption->description,
                'status' => 'available',
                'is_active' => 1,
            ]);

            // $guardianEmail = $adoption->guardian_email; // Replace with the actual field name containing the guardian's email
            // Mail::to($guardianEmail)->send(new approveRequestNotification($adoption));

            // Delete the Request record
            $adoption->delete();

            // Optionally, emit an event or perform any other necessary actions
            $this->dispatch('adoptionApproved', $pet->id);

            session()->flash('success', 'Adoption request approved successfully!');
        } else {
            session()->flash('error', 'Adoption request not found!');
        }
    }

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($petId)
    {
        $this->user = Request::find($petId);

        return Redirect::route('admin.request.edit', ['id' => $petId]);
    }

    public function deleteUser($userId)
    {
        $adoption = Request::find($userId);

        if ($adoption) {
            // Get the guardian's email before deleting
            $guardianEmail = $adoption->guardian_email;
            $guardianName = $adoption->guardian;

            // Delete the Request record
            $adoption->delete();

            // Mail::to($guardianEmail)->send(new rejectRequestNotification($guardianEmail, $guardianName));

            $this->render();

            session()->flash('success', 'Adoption request Reject successfully!');

            return redirect()->route('admin.request.index');
        } else {
            session()->flash('error', 'Something went Wrong!');
        }
    }




    public function render()
    {
        $this->animalCount = Request::count();
        $this->dogCount = Request::where('pet_type', 'dog')->count();
        $this->catCount = Request::where('pet_type', 'cat')->count();

        $requests = Request::where('name', 'like', '%' . $this->searchTerm . '%')->paginate(3);

        return view('livewire.request-admin', [
            'requests' => $requests,
        ]);
    }
}
