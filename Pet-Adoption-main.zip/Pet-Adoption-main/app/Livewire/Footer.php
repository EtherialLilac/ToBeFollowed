<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Donation;

class Footer extends Component
{

    public $search = '';
    
    public function render()
    {
        $donations = Donation::where('name', 'like', '%' . $this->search . '%')
            ->orWhere('amount', 'like', '%' . $this->search . '%')
            ->paginate(10);

        return view('livewire.footer', ['donations' => $donations]);
    }
}
