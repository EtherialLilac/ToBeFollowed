<?php

namespace App\Livewire;

use App\Models\Adopt;
use Livewire\Component;
use Livewire\WithPagination;
use App\Mail\AdoptionRequest;
use App\Mail\approveNotification;
use App\Mail\rejectNotification;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

class AdoptsAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $animalCount;
    public $dogCount;
    public $catCount;
    public $searchTerm = '';

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($petId)
    {
        $this->user = Adopt::find($petId);

        return Redirect::route('admin.adopt.edit', ['id' => $petId]);
    }

    public function deleteUser($userId)
    {
        Adopt::find($userId)->delete();
        $this->render();
    }

    public function approveAdoption($petId)
    {
        $adoption = Adopt::find($petId);

        if ($adoption) {
            // Update the Adopt table
            $adoption->delete();

            // Update the Pet table
            $pet = $adoption->pet;
            if ($pet) {
                $pet->update(['is_active' => 0]);
            }

            // Mail::to($adoption->adopt_email)->send(new approveNotification($adoption, $pet));
        
            session()->flash('success', 'Adoption Request is Approved!');

            // Refresh the Livewire component
            $this->render();
        }
    }

    public function rejectAdoption($petId)
    {
        $adoption = Adopt::find($petId);

        if ($adoption) {
            // Update the Adopt table
            $adoption->delete();

            // Update the Pet table
            $pet = $adoption->pet;
            if ($pet) {
                // $pet->update(['is_active' => 1]);
            }

        //    Mail::to($adoption->adopt_email)->send(new rejectNotification($adoption, $pet));
        
            session()->flash('success', 'Adoption Request is Rejected!');

            // Refresh the Livewire component
            $this->render();
        }
    }

    public function render()
    {
        $this->animalCount = Adopt::count();
        $this->dogCount = Adopt::whereHas('pet', function ($query) {
            $query->where('name', 'like', '%' . $this->searchTerm . '%')->where('pet_type', 'dog');
        })->count();

        $this->catCount = Adopt::whereHas('pet', function ($query) {
            $query->where('name', 'like', '%' . $this->searchTerm . '%')->where('pet_type', 'cat');
        })->count();

        $pets = Adopt::whereHas('pet', function ($query) {
            $query->where('name', 'like', '%' . $this->searchTerm . '%');
        })->paginate(3);

        return view('livewire.adopts-admin', [
            'pets' => $pets,
        ]);
    }
}
