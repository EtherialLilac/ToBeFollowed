<?php

namespace App\Livewire;

use App\Models\Adopt;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\Features\SupportFileUploads\WithFileUploads;

class EditAdoptsAdmin extends Component
{
    use WithFileUploads;

    public $petId;
    public $name;
    public $slug;
    public $age;
    public $type;
    public $image;
    public $guardian;
    public $contact;
    public $status;
    public $isActive;

    protected $listeners = ['updatedName'];

    public function updatedName($value)
    {
        $this->slug = Str::slug($value);
    }

    public function mount($petId)
    {
        $this->petId = $petId;
        $this->loadUserData();
    }

    public function loadUserData()
    {
        $pet = Adopt::find($this->petId);

        if ($pet) {
            $this->name = $pet->name;
            $this->slug = $pet->slug;
            $this->age = $pet->age;
            $this->image = $pet->image;
            $this->type = $pet->pet_type;
            $this->guardian = $pet->guardian;
            $this->contact = $pet->contact;
            $this->status = $pet->status;
            $this->isActive = $pet->is_active;
        }
    }

    public function update()
    {
        $pet = Adopt::find($this->petId);

        if ($pet) {
            // Handle file upload
            if ($this->image) {
                $imagePath = $this->image->store('public/images');
                $pet->image = basename($imagePath);
            }

            $pet->update([
                'name' => $this->name,
                'slug' => $this->slug,
                'age' => $this->age,
                'pet_type' => $this->type,
                'guardian' => $this->guardian,
                'contact' => $this->contact,
                'status' => $this->status,
                'is_active' => $this->isActive
            ]);

            // Emit an event to trigger the loadUserData method after the update
            $this->dispatch('userDataUpdated');
        }

        return redirect()->route('admin.pets.index');
    }

    public function render()
    {
        return view('livewire.edit-adopts-admin');
    }
}
