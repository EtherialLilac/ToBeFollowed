<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Illuminate\Support\Facades\Hash;

class CreateUsersAdmin extends Component
{
    public $name;
    public $email;
    public $password;
    public $isAdmin = 0;

    public function render()
    {
        return view('livewire.create-users-admin');
    }

    public function createUser()
    {
        $this->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
        ], [
            'email.unique' => 'The email is already taken.',
            'password.min' => 'The password must be at least 6 characters.',
        ]);

        $hashedPassword = bcrypt($this->password);

        User::create([
            'name' => $this->name,
            'email' => $this->email,
            'password' => $hashedPassword,
            'isAdmin' => $this->isAdmin,
        ]);

        session()->flash('success', 'User created successfully.');

        return redirect()->route('admin.users.index');
    }
}
