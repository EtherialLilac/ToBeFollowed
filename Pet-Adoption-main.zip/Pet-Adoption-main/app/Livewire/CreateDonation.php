<?php

namespace App\Livewire;

use App\Models\Donation;
use Livewire\Component;

class CreateDonation extends Component
{

    public $name;
    public $email;
    public $contact;
    public $amount;

    public function render()
    {
        return view('livewire.create-donation');
    }

    public function createUser()
    {
        Donation::create([
            'name' => $this->name,
            'email' => $this->email,
            'contact' => $this->contact,
            'payment_method' => 'cash',
            'amount' => $this->amount,
        ]);

        session()->flash('success', 'Donation created successfully.');

        return redirect()->route('admin.donation.index');
    }
}
