<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Tag;

class EditTagAdmin extends Component
{
    public $userId;
    public $name;
    public $slug;
    public $isActive;

    public function mount($userId)
    {
        $this->userId = $userId;
        $this->loadUserData();
    }

    public function loadUserData()
    {
        $user = Tag::find($this->userId);

        if ($user) {
            $this->name = $user->name;
            $this->slug = $user->slug;
            $this->isActive = $user->is_active;
        }
    }

    public function update()
    {
        $this->slug = strtolower(str_replace(' ', '-', $this->name));
        $user = Tag::find($this->userId);

        if ($user) {
            $user->update([
                'name' => $this->name,
                'slug' => $this->slug,
                'is_active' => $this->isActive,
            ]);

            // Emit an event to trigger the loadUserData method after the update
            $this->dispatch('userDataUpdated');
        }

        // Redirect or perform other actions after the update
        // You can redirect to the user index page, for example
        return redirect()->route('admin.tag.index');
    }

    public function render()
    {
        return view('livewire.edit-tag-admin');
    }
}
