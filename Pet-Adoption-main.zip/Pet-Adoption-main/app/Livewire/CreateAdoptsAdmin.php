<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Adopt;
use Livewire\WithFileUploads;

class CreateAdoptsAdmin extends Component
{
    use WithFileUploads;
    
    public $name;
    public $slug;
    public $age;
    public $type;
    public $guardian;
    public $contact;
    public $status;
    public $image;
    public $isActive = 0;

    public function render()
    {
        return view('livewire.create-adopts-admin');
    }

    public function create()
    {
        // Generate the slug before creating the pet
        $this->slug = strtolower(str_replace(' ', '-', $this->name));
    
        if ($this->image) {
            // Store the image in storage/app/public/images
            $imagePath = $this->image->store('images', 'public');
        }
    
        Adopt::create([
            'name' => $this->name,
            'slug' => $this->slug,
            'age' => $this->age,
            'pet_type' => $this->type,
            'guardian' => $this->guardian,
            'contact' => $this->contact,
            'status' => $this->status,
            'image' => $imagePath ?? null,
            'is_active' => $this->isActive,
        ]);
    
        $this->dispatch('userDataUpdated');
    
        return redirect()->route('admin.adopt.index');
    }
}
