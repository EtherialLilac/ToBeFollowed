<?php

namespace App\Livewire;

use App\Models\Tag;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Redirect;

class TagAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $animalCount;
    public $dogCount;
    public $catCount;
    public $searchTerm = '';

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($petId)
    {
        $this->user = Tag::find($petId);

        return Redirect::route('admin.tag.edit', ['id' => $petId]);
    }

    public function deleteUser($userId)
    {
        Tag::find($userId)->delete();
        $this->render();
    }

    public function render()
    {
        
        $pets = Tag::where('name', 'like', '%' . $this->searchTerm . '%')    
        ->paginate(10);

        return view('livewire.tag-admin', [
            'pets' => $pets,
        ]);
    }
}
