<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Redirect;

class UsersAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $userCount;
    public $adminCount;
    public $searchTerm = '';

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($userId)
    {
        $this->user = User::find($userId);

        return Redirect::route('admin.users.edit', ['id' => $userId]);
    }

    public function deleteUser($userId)
    {
        User::find($userId)->delete();
        $this->render();
    }

    public function render()
    {
        $this->userCount = User::count();
        $this->adminCount = User::where('isAdmin', 1)->count();

        $users = User::where('name', 'like', '%' . $this->searchTerm . '%')->paginate(10);

        return view('livewire.users-admin', [
            'users' => $users,
        ]);
    }
}
