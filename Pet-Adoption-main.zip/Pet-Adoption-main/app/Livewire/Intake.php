<?php

namespace App\Livewire;

use App\Mail\intakeRequest;
use App\Models\Request;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class Intake extends Component
{
    use WithFileUploads;

    public $petName;
    public $petSlug;
    public $petAge;
    public $petType;
    public $slug;
    public $petBreed;
    public $fileInput;
    public $email;
    public $document;
    public $description;
    public $guardianName;
    public $guardianContact;

    public function create()
    {
        if (!auth()->check()) {
            Session::flash('success', 'Please login first to Continue!');
            return redirect()->route('login');
        }

        $filePath = $this->fileInput->store('images', 'public');
        $document = $this->fileInput->store('images', 'public');

        // Create a new Request instance
        $pet = Request::create([
            'name' => $this->petName,
            'slug' => Str::slug($this->petName),
            'age' => $this->petAge,
            'pet_type' => $this->petType,
            'breed' => $this->petBreed,
            'image' => $filePath,
            'document' => $document,
            'guardian_email' => $this->email,
            'description' => $this->description,
            'guardian' => $this->guardianName,
            'status' => 'pending',
            'contact' => $this->guardianContact,
        ]);

        // Clear form fields
        $this->reset([
            'petName',
            'petAge',
            'petType',
            'petBreed',
            'fileInput',
            'description',
            'email',
            'document',
            'guardianName',
            'guardianContact',
        ]);

        // $user = auth()->user();
        // Mail::to($user->email)->send(new intakeRequest($pet));

        // Add a success message to the session
        Session::flash('success', 'Adoption request submitted successfully!');

        return redirect()->route('intake.foster');
    }



    public function render()
    {
        return view('livewire.intake');
    }
}
