<?php

namespace App\Livewire;

use App\Models\Pet;
use App\Models\Tag;
use App\Models\PetTag;
use Livewire\Component;
use Livewire\WithFileUploads;

class CreatePetsAdmin extends Component
{
    use WithFileUploads;

    public $tags;
    public $name;
    public $slug;
    public $age;
    public $type;
    public $guardian;
    public $contact;
    public $status;
    public $breed;
    public $image;
    public $isActive = 1;
    public $selectedTags = [];

    public function mount()
    {
        $this->tags = Tag::all();
    }

    public function updatedSelectedTags()
    {
        // Add logic to update the Pet_Tag table when tags are selected or deselected
        $petId = 1; // Replace with the actual pet_id
        PetTag::where('pet_id', $petId)->delete(); // Clear existing tags for the pet

        foreach ($this->selectedTags as $tagId) {
            PetTag::create(['pet_id' => $petId, 'tag_id' => $tagId]);
        }
    }

    public function render()
    {
        return view('livewire.create-pets-admin');
    }

    public function create()
    {
        // Generate the slug before creating the pet
        $this->slug = strtolower(str_replace(' ', '-', $this->name));

        if ($this->image) {
            // Store the image in storage/app/public/images
            $imagePath = $this->image->store('images', 'public');
            
        }

        $pet =  Pet::create([
            'name' => $this->name,
            'slug' => $this->slug,
            'age' => $this->age,
            'breed' => $this->breed,
            'pet_type' => $this->type,
            'guardian' => $this->guardian,
            'contact' => $this->contact,
            'status' => $this->status,
            'image' => $imagePath ?? null,
            'is_active' => $this->isActive,
        ]);

        $this->dispatch('userDataUpdated');
        session()->flash('success', 'Pet Created successfully!');
        return redirect()->route('admin.pets.edit', ['id' => $pet->id]);
    }
}
