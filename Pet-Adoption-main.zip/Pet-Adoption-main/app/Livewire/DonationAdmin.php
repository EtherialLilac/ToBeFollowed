<?php

namespace App\Livewire;

use App\Models\Donation;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Redirect;

class DonationAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $donationCount;
    public $totalDonation;
    public $searchTerm = '';

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($userId)
    {
        $this->user = Donation::find($userId);

        return Redirect::route('admin.users.edit', ['id' => $userId]);
    }

    public function deleteUser($userId)
    {
        Donation::find($userId)->delete();
        $this->render();
    }

    public function render()
    {
        $this->donationCount = Donation::count();
        $this->totalDonation = Donation::sum('amount');

        $users = Donation::where('name', 'like', '%' . $this->searchTerm . '%')->paginate(10);

        return view('livewire.donation-admin', [
            'users' => $users,
        ]);
    }
}
