<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Donation;
use Ixudra\Curl\Facades\Curl;
use Illuminate\Support\Facades\Session;

class ApiDonation extends Component
{
    public $selectedAmount = 100;

    public function render()
    {
        return view('livewire.api-donation');
    }

    public function donate()
    {
        $data = [
            'data' => [
                'attributes' => [
                    'line_items' => [
                        [
                            'currency' => 'PHP',
                            'amount' => $this->selectedAmount * 100,
                            'description' => auth()->user()->name,
                            'name' => 'Donation',
                            'quantity' => 1,
                        ],
                    ],
                    'payment_method_types' => ['gcash'],
                    'success_url' => route('payment.success'),
                    'cancel_url' => route('payment.cancel'),
                    'description' => 'Donation for Cats of New Port',
                ],
            ],
        ];

        $response = Curl::to('https://api.paymongo.com/v1/checkout_sessions')
            ->withHeader('Content-Type: application/json')
            ->withHeader('accept: application/json')
            ->withHeader('Authorization: Basic c2tfdGVzdF9lS3JHSm1RdDV2VlUzUnRIZGJaa1JHTWs6')
            ->withData($data)
            ->asJson()
            ->post();

        Session::put('session_id', $response->data->id);

        return redirect()->to($response->data->attributes->checkout_url);
    }

    public function onSuccess()
    {
        $paymentSessionId = Session::get('session_id');

        $amount = $this->selectedAmount;

        $donation = new Donation([
            'name' => auth()->user()->name,
            'email' => auth()->user()->email,
            'contact' => auth()->user()->contact ? : null, 
            'payment_method' => 'gcash',
            'amount' => $amount,
        ]);

        $donation->save();

        return view('payment-success');
    }

    public function onError()
    {
        return view('payment-cancel');
    }
}
