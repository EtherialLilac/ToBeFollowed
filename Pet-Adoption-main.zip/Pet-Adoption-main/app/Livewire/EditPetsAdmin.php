<?php

namespace App\Livewire;

use App\Models\Pet;
use App\Models\Tag;
use App\Models\PetTag;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\Features\SupportFileUploads\WithFileUploads;

class EditPetsAdmin extends Component
{
    use WithFileUploads;

    public $tags;
    public $petId;
    public $name;
    public $slug;
    public $age;
    public $type;
    public $image;
    public $guardian;
    public $contact;
    public $breed;
    public $status;
    public $description;
    public $isActive;
    public $selectedTags = [];

    protected $listeners = ['updatedName'];

    public function updatedName($value)
    {
        $this->slug = Str::slug($value);
    }

    public function mount($petId)
    {
        $this->petId = $petId;
        $this->loadUserData();
        $this->tags = Tag::all()->where('is_active', 1);
    }

    public function updatedSelectedTags()
    {
        // Add logic to update the Pet_Tag table when tags are selected or deselected
        PetTag::where('pet_id', $this->petId)->delete(); // Clear existing tags for the pet

        foreach ($this->selectedTags as $tagId) {
            PetTag::create(['pet_id' => $this->petId, 'tag_id' => $tagId]);
        }
    }

    public function loadUserData()
    {
        $pet = Pet::find($this->petId);

        if ($pet) {
            $this->name = $pet->name;
            $this->slug = $pet->slug;
            $this->age = $pet->age;
            $this->breed = $pet->breed;
            $this->image = $pet->image; // Set the value of the image property
            $this->type = $pet->pet_type;
            $this->guardian = $pet->guardian;
            $this->contact = $pet->contact;
            $this->description = $pet->description;
            $this->status = $pet->status;
            $this->isActive = $pet->is_active;
            $this->selectedTags = $pet->tags->pluck('id')->toArray();
        }
    }


    public function update()
    {
        $pet = Pet::find($this->petId);

        if ($pet) {
            // Check if a new file is uploaded
            if ($this->image && $this->image != $pet->image) {
                // If a new file is uploaded and it's different from the existing image, update the image field
                $imagePath = $this->image->store('images', 'public');
                $imageName = 'images/' . basename($imagePath); // Prepend "images/" to the image name
                $pet->image = $imageName;
            }

            $pet->update([
                'name' => $this->name,
                'slug' => $this->slug,
                'age' => $this->age,
                'breed' => $this->breed,
                'pet_type' => $this->type,
                'guardian' => $this->guardian,
                'contact' => $this->contact,
                'description' => $this->description,
                'status' => $this->status,
                'is_active' => $this->isActive
            ]);

            // Emit an event to trigger the loadUserData method after the update
            $this->dispatch('userDataUpdated');
        }
        session()->flash('success', 'Pet updated successfully!');
        return redirect()->route('admin.pets.edit', ['id' => $pet->id]);
    }



    public function render()
    {
        return view('livewire.edit-pets-admin');
    }
}
