<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Tag;

class CreateTagAdmin extends Component
{
    public $name;
    public $slug;
    public $isAdmin;

    public function render()
    {
        return view('livewire.create-tag-admin');
    }

    public function createUser()
    {
        $this->slug = strtolower(str_replace(' ', '-', $this->name));
        
        Tag::create([
            'name' => $this->name,
            'slug' => $this->slug,
            'is_active' => 1,
        ]);

        session()->flash('success', 'Tag created successfully.');

        return redirect()->route('admin.tag.index');
    }
}
