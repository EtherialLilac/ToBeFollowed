<?php

namespace App\Livewire;

use App\Models\Pet;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Illuminate\Support\Facades\Redirect;

class PetsAdmin extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $user;
    public $animalCount;
    public $dogCount;
    public $catCount;
    public $searchTerm = '';

    public function updateSearch()
    {
        $this->resetPage();
    }

    public function editUser($petId)
    {
        $this->user = Pet::find($petId);

        return Redirect::route('admin.pets.edit', ['id' => $petId]);
    }

    public function deleteUser($userId)
    {
        Pet::find($userId)->delete();
        $this->render();
    }

    public function render()
    {
        $this->animalCount = Pet::count();
        $this->dogCount = Pet::where('pet_type', 'dog')->where('is_active', 1)->count();
        $this->catCount = Pet::where('pet_type', 'cat')->where('is_active', 1)->count();

        $pets = Pet::where('name', 'like', '%' . $this->searchTerm . '%')
            ->where('is_active', 1)
            ->paginate(3);

        return view('livewire.pets-admin', [
            'pets' => $pets,
        ]);
    }
}
