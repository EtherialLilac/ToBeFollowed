<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;

class EditUsersAdmin extends Component
{
    public $userId;
    public $name;
    public $email;
    public $isAdmin;

    public function mount($userId)
    {
        $this->userId = $userId;
        $this->loadUserData();
    }

    public function loadUserData()
    {
        $user = User::find($this->userId);

        if ($user) {
            $this->name = $user->name;
            $this->email = $user->email;
            $this->isAdmin = $user->isAdmin;
        }
    }

    public function update()
    {
        $user = User::find($this->userId);

        if ($user) {
            $user->update([
                'name' => $this->name,
                'email' => $this->email,
                'isAdmin' => $this->isAdmin,
            ]);

            // Emit an event to trigger the loadUserData method after the update
            $this->dispatch('userDataUpdated');
        }

        // Redirect or perform other actions after the update
        // You can redirect to the user index page, for example
        return redirect()->route('admin.users.index');
    }


    public function render()
    {
        return view('livewire.edit-users-admin');
    }
}
