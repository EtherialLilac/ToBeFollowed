<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Adopt extends Model
{
    use HasFactory;

    protected $fillable = [
        'pet_id',
        'status',
        'is_active',
        'adopt_name',
        'adopt_email',
        'adopt_contact',
    ];

    public function pet()
    {
        return $this->belongsTo(Pet::class, 'pet_id');
    }
}
