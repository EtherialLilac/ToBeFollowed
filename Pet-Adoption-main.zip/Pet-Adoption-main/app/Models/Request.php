<?php

namespace App\Models;

use App\Models\Pet;
use App\Models\PetTag;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Request extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'age',
        'image',
        'document',
        'pet_type',
        'guardian',
        'guardian_email',
        'contact',
        'breed',
        'description',
        'status',
        'is_active',
    ];

    public function pet()
    {
        return $this->belongsTo(Pet::class);
    }

    public function petTags()
    {
        return $this->hasMany(PetTag::class);
    }
}
