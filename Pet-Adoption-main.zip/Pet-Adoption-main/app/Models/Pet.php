<?php

namespace App\Models;

use App\Mail\AdoptionRequest;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pet extends Model
{
    use HasFactory;

    protected $table = 'pets';

    protected $fillable = [
        'name',
        'slug',
        'age',
        'breed',
        'image',
        'description',
        'pet_type',
        'guardian',
        'contact',
        'status',
        'tags',
        'is_active',
    ];

   
    public function tags()
    {
        return $this->belongsToMany(Tag::class);
    }

    public function adopts()
    {
        return $this->hasMany(Adopt::class);
    }

    public function adoptionRequests()
    {
        return $this->hasMany(Request::class);
    }
}
