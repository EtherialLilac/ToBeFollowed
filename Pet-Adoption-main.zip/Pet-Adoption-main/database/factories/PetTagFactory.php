<?php

namespace Database\Factories;

use App\Models\Pet;
use App\Models\Tag;
use App\Models\PetTag;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class PetTagFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    protected $model = PetTag::class;
    
    public function definition(): array
    {
        return [
            'tag_id' => Tag::inRandomOrder()->value('id'),
            'pet_id' => Pet::inRandomOrder()->value('id'),
        ];
    }
}
