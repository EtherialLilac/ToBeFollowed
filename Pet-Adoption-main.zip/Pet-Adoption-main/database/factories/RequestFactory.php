<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Request>
 */
class RequestFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => $this->faker->name(),
            'slug' => $this->faker->name(),
            'breed' => $this->faker->name(),
            'age' => $this->faker->numberBetween(1, 20),
            'image' => null,
            'pet_type' => $this->faker->randomElement(['dog', 'cat']),
            'guardian' => $this->faker->name(),
            'description' => $this->faker->name(),
            'guardian_email' => $this->faker->email(),
            'contact' => $this->faker->phoneNumber(),
            'status' => $this->faker->randomElement(['available', 'adopted', 'pending']),
            'is_active' => 1,
        ];
    }
}
