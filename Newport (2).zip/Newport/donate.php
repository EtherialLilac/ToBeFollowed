<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CATS OF NEWPORT CITY</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
        <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link ">About Us</a>
                    <a href="donate.php" class="nav-item nav-link active">Donate</a>
                    <a href="adopt.php" class="nav-item nav-link">Adopt</a>
					<a href="intake.php" class="nav-item nav-link">Intake & Foster</a>
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->





    <!-- spaynueter Start -->
    <div class="container pt-5">
  
        <div class="row pb-3">
		
		
            <div class="col-lg-12 mb-4">
                <div class="card border-0 mb-2">
                   
                    <div class="card-body bg-light p-4">
                       
		<div class="d-flex flex-column text-left mb-2">
            <h3 class="display-5 m-0"><span class="text-primary">Why Donate?</h3><br>
        </div>
		
			<center>   
                        <p><b>GROWING COMPASSION</b><br><br>
Through education and awareness drives, more and more and joining the cause.<br><br>
Cats of Ayala Technohub<br>
Cats of Ayala Malls<br>
Cats Around Town (Town Center, Alabang)<br>
Cats of BGC<br>
Cats of Legaspi Village<br>
Cats of Eton Centris<br>
Cats of Trion Towers<br>
Cats of Greenfield<br>
Cats of Ortigas<br>
CATeneo<br>
Cats of U.P.<br>
Cats of Ayala Alabang Village<br>
Cats of Circulo Verde<br>
Cats of McKinley<br>
Cats of El Pueblo<br>
Cats of Sorrento<br>
Cats of Illumina<br>
Cats of Daang Hari<br>
Cats of Quezon<br>
Cats of Iloilo<br>
Cats of Lexington</p>
          
						<a href="donatenow.php" class="btn btn-lg btn-primary mt-0 mt-md-4 px-4">DONATE NOW</a>
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div>
    <!-- spaynueter End -->






<br>
<br>
<hr style="width: 70%;">





    <!-- ABout Start -->
    <div class="container pt-5">
	
	<center>
	
  <p class="m-0">These Donations go a long way in providing the needs of our partnership shelter animals. Below is the list of items they need on a daily basis:</p>
  
	</center>

<br>
	<center>
	<div class="row">


	
			<div class="col-lg-5 mb-3 mx-auto" style="background-color: #ED6436; border-radius: 15px; margin: 20px;" >
                <div class="card border-2 mb-2 mt-2">   
				<center>
                    <div class="card-body p-4">
                        <h3 class="card-title text-truncate">PET WISH LIST</h3>
                    <p style="text-align: justify;">• Dog and Cat food (kibble and canned)<br>
• Crates, carriers or cages<br>
• Pet diapers and wee wee pads<br>
• Scratching posts for the cats<br>
• Chew toys for the dogs<br>
• Vaccines, medicine and vitamins<br>
• Dog and cat treats<br>
• Leashes, harnesses and collars</p><br>
                    </div>
				</center>
                </div>
            </div>


	
			<div class="col-lg-5 mb-3 mx-auto" style="background-color: #ED6436; border-radius: 15px; margin: 20px;" >
                <div class="card border-2 mb-2 mt-2">   
				<center>
                    <div class="card-body p-4">
                        <h3 class="card-title text-truncate">SHELTER WISH LIST</h3>
                        <p style="text-align: justify;">• Detergent powder and bleach<br>
• Dishwashing paste or liquid<br>
• Bath towels<br>
• Garbage bags (XXL)<br>
• Foot rugs or door mats<br>
• Clinic supplies (alcohol, cotton, etc.)<br>
• Old newspapers<br>
• Toilet paper<br>
• Mops and brooms
                    </div>
				</center>
                </div>
            </div>


	</div>	
	</center>

   </div>
    <!-- ABout End -->





<br>
<br>
<hr style="width: 70%;">





    <!-- sponsor Start -->
    <!--div class="container pt-5">
        
        <div class="row pb-3">
		
		
            <div class="col-lg-12 mb-4">
                <div class="card border-0 mb-2">
                   
                    <div class="card-body bg-light p-4">
              
			<div class="d-flex flex-column text-center mb-5">
            <h6 class="display-5 m-0"><span class="text-dark">OTHER WAYS TO GIVE</h6>
			</div>
			<div class="d-flex flex-column text-left mb-3">
            <h3 class="display-5 m-0"><span class="text-primary">Sponsor an animal</h3>
			</div>
			
			<div class="row">
                
			<div class="col-lg-6 mb-3">      
                        <p>We understand the you may not be able to take one of our furry residents home, but you can still enjoy a wonderful connection through HUMAMIN's sponsorship program!</p>
            </div>
			
			<div class="col-lg-6 mb-3">         
					<img class="card-img-top" src="img/blog-2.jpg" alt="">
            </div>
			
			</div>   
			
			<center>  
                       
						<a href="sponsor.php" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">Sponsor an Animal</a>
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div---->
    <!-- sponsor End -->



<br>
<br>
<hr style="width: 70%;">





    <!-- sponsor Start -->
    <div class="container pt-5">
        
        <div class="row">
		
	
			

			<div class="col-lg-4 mb-4 mx-auto">
					
						<h5><b>Account Name:</b> SA*******A JA*E A.</h5><br>
						<h5><b>Account Number:</b> 09173260175</h5>
					
			</div>
				
			
			
			<div class="col-lg-4 mb-4 mx-auto">
				<center>
					<h4>DONATE VIA GCASH</h4>
					<img src="img/code.jpg" style="width: 40%; height: 40%"/>
				</center>
            </div>
			
		</div>		
   </div>
    <!-- sponsor End -->











<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/65b26bcd8d261e1b5f57e5db/1hl0fa7lo';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->




    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>