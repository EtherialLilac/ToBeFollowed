<?php
include 'dbconfig.php';

$dbHost = $host;
$dbUser = $username;
$dbPass = $password;
$dbName = $database;

// Retrieve the parameters
$table = $_GET['table'];
$column = $_GET['column'];
$newValue = $_GET['new_value'];
$id = $_GET['id'];

// Create a new database connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL statement to update the value
$sql = "UPDATE $table SET $column = '$newValue' WHERE ID = '$id'";

// Execute the statement
if ($conn->query($sql) === TRUE) {
    // Update successful
    echo "Value updated successfully!";
} else {
    // Update failed
    echo "Error updating value: " . $conn->error;
}

// Close the connection
$conn->close();
?>
