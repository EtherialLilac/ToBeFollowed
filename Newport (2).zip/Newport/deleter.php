<?php
include 'dbconfig.php';

$dbHost = $host;
$dbUser = $username;
$dbPass = $password;
$dbName = $database;

// Retrieve the parameters
$table = $_GET['table'];
$id = $_GET['id'];

// Create a new database connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL statement to delete the row
$sql = "DELETE FROM $table WHERE ID = '$id'";

// Execute the statement
if ($conn->query($sql) === TRUE) {
    // Deletion successful
    echo "Row deleted successfully!";
} else {
    // Deletion failed
    echo "Error deleting row: " . $conn->error;
}

// Close the connection
$conn->close();
?>
