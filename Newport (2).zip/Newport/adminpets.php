<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	
	

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
            <a href="" class="navbar-brand d-block d-lg-none">
                <h1 class="m-0 display-5 text-capitalize font-italic text-white"><span class="text-primary">Pawsome</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <h1 class="m-0 display-5 text-capitalize"><span class="text-primary">Pawsome</h1>
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="adminadoption.php" class="nav-item nav-link ">Adoption</a>
					<a href="adminintake.php" class="nav-item nav-link ">Intake & Foster</a>
					<a href="adminpets.php" class="nav-item nav-link active">Manage Pets</a>
					<a onclick="logout()" class="nav-item nav-link ">Logout</a>
                   
					
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->


    <!-- Carousel Start -->
    <div class="container-fluid p-0">
     
	 <hr style="border: 0px solid white; margin: 20px;">
			
                 <div class="col-11 mx-auto" style="">
                            <h3 class="text-dark mb-3 text-center d-none d-sm-block">PET MANAGEMENT</h3>

								<div class="row">
								
<?php
// Replace these with your actual database credentials


include 'dbconfig.php';

$servername = $host;
$dbname = $database;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute the SQL query to retrieve data
$sql = "SELECT * FROM intake where status = 'APPROVED' OR status = 'ADOPTED'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row as cards
    while ($row = $result->fetch_assoc()) {
		
		$color = "orange";
		$status = $row["status"];
		
		if($row["status"] == "") {$status = "PENDING";}
		
		if($status == "APPROVED") {$status = "AVAILABLE"; $color = "green";}
		if($status == "ADOPTED") {$color = "red";}

        echo '<div class="col-lg-4 col-md-12 card mx-auto mr-3 " style="padding: 0px;">
                  
					  <img src="'.$row["petimage"].'" style="width: 100%; height: 200px; object-fit: cover;" class="card-img-top" alt="...">
					  <div class="card-body">
						<h5 class="card-title">'. $row["ID"] .'. '.$row["petname"].'</h5>
						<p class="card-text">'.$row["petage"].' year old '.$row["petbreed"].' '.$row["petType"].' who loves '.$row["activities"].'.</p>
						<p style="margin: 1px;" class="card-text"><b>Guardian: </b>'.$row["guardian_name"].'</p>
						<p style="margin: 1px;" class="card-text"><b>Contact: </b>'.$row["guardian_contact"].'</p>
						<p style="margin: 1px;" class="card-text"><b>Status: </b><font style="color: '.$color .';">'.$status.'</font></p>
						<br>
						<p class="card-text"><small class="text-muted">Requested on '.$row["submission_date"].'</small></p>
					
					<center>
					<a onclick="available'. $row["ID"] .'('. $row["ID"] .')" class="btn btn-success">AVAILABLE</a>
                    <a onclick="adopt'. $row["ID"] .'('. $row["ID"] .')" class="btn btn-danger">ADOPTED</a>                    
                    <a onclick="deleter'. $row["ID"] .'('. $row["ID"] .')" class="btn btn-dark">Delete</a>
					</center>
					</div>
                </div>
				
<script>				
function deleter'. $row["ID"] .'(ids) {
                    var tabs = "intake";
                    var confirmation = confirm("Are you sure you want to delete this record?");
                    if (!confirmation) {
                        return;
                    }
                    $.ajax({
                        type: "GET",
                        url: "deleter.php",
                        data: {
                            table: tabs,
                            id: ids
                        },
                        success: function(result) {
							alert("DELETED!");
                            location.reload();
                        },
                        error: function() {
                            alert("ERROR!");
                        }
                    });
}	


function available'. $row["ID"] .'(ids) {
    var table = "intake"; // Change this if needed
    var column = "status"; // Change this if needed
    var newValue = "APPROVED"; // Change this if needed

    var confirmation = confirm("Available this record?");
    if (!confirmation) {
        return;
    }

    $.ajax({
        type: "GET",
        url: "updater.php", // Replace with the correct URL of your PHP script
        data: {
            table: table,
            column: column,
            new_value: newValue,
            id: ids
        },
        success: function(result) {
            alert("Pet is available!");
            location.reload();
        },
        error: function() {
            alert("Error.");
        }
    });
}	

function adopt'. $row["ID"] .'(ids) {
    var table = "intake"; // Change this if needed
    var column = "status"; // Change this if needed
    var newValue = "ADOPTED"; // Change this if needed

    var confirmation = confirm("Adopt this pet?");
    if (!confirmation) {
        return;
    }

    $.ajax({
        type: "GET",
        url: "updater.php", // Replace with the correct URL of your PHP script
        data: {
            table: table,
            column: column,
            new_value: newValue,
            id: ids
        },
        success: function(result) {
            alert("Pet Adopted!");
            location.reload();
        },
        error: function() {
            alert("Error.");
        }
    });
}	



			
</script>				
				
				
				
				
				';
				
				
				
				
    }
} else {
    echo "0 results";
}

$conn->close();
?>

								
							
								
								
				 </div>				
		
        </div>
    </div>
    <!-- Carousel End -->





    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
<script>
function logout() {
    // Clear the value in localStorage for session status
    localStorage.removeItem("session_status");
    window.location = "adminlogin.php"; // Redirect to the login page after logging out
}

function checkSession() {
    const sessionStatus = localStorage.getItem("session_status");
    
    if (sessionStatus !== "SESSION_ACTIVE" || !sessionStatus) {
        logout();
    }
}

// Perform initial check and start checking the session status every 5 seconds
checkSession();
setInterval(checkSession, 1000); // Adjust the interval as needed
</script>
</body>

</html>