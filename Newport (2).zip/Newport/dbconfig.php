<?php


$username="root";
$password="";
$host="localhost";
$database="huamin_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error)
{
    die('connection failed :'.$conn->connect_error );
}


?>