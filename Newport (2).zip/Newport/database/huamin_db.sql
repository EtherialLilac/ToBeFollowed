-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2024 at 02:36 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `huamin_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoption`
--

CREATE TABLE `adoption` (
  `ID` int(11) NOT NULL,
  `petID` int(11) NOT NULL,
  `name` varchar(1024) NOT NULL,
  `address` varchar(1024) NOT NULL,
  `age` varchar(1024) NOT NULL,
  `contact` varchar(1024) NOT NULL,
  `altcontact` varchar(1024) NOT NULL,
  `occupation` varchar(1024) NOT NULL,
  `email` varchar(1024) NOT NULL,
  `gender` varchar(1024) NOT NULL,
  `date` varchar(1024) NOT NULL,
  `time` varchar(1024) NOT NULL,
  `status` varchar(1024) NOT NULL,
  `petname` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption`
--

INSERT INTO `adoption` (`ID`, `petID`, `name`, `address`, `age`, `contact`, `altcontact`, `occupation`, `email`, `gender`, `date`, `time`, `status`, `petname`) VALUES
(13, 18, 'Victoria Jaranillla', '460 inarawan', '23', '09653623830', '09983604539', 'Teacher', 'etheriouslilac@gmail.com', 'Female', '2024-01-14', '09:00', 'pending', 'blacky'),
(14, 20, 'Victoria Jaranillla', '460 inarawan', '23', '09653623830', '09983604539', 'Teacher', 'etheriouslilac@gmail.com', 'Female', '2024-01-12', '18:58', 'APPROVED', 'panda');

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `Id` int(11) NOT NULL,
  `Firstname` varchar(500) NOT NULL,
  `Lastname` varchar(500) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Number` varchar(500) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `Amount` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`Id`, `Firstname`, `Lastname`, `Address`, `Number`, `Email`, `Amount`) VALUES
(1, 'Arahvela', 'Siena', '460', '095457458415456', 'etheriouslilac@gmail.com', '2000'),
(2, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `intake`
--

CREATE TABLE `intake` (
  `ID` int(11) NOT NULL,
  `petname` varchar(255) NOT NULL,
  `petage` int(11) NOT NULL,
  `petType` varchar(255) NOT NULL,
  `petbreed` varchar(255) NOT NULL,
  `guardian_name` varchar(255) NOT NULL,
  `guardian_contact` varchar(255) NOT NULL,
  `petimage` varchar(255) NOT NULL,
  `activities` text DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `intake`
--

INSERT INTO `intake` (`ID`, `petname`, `petage`, `petType`, `petbreed`, `guardian_name`, `guardian_contact`, `petimage`, `activities`, `submission_date`, `status`) VALUES
(11, 'lazy', 1, 'Cat', 'puspin', 'Newport', '09173260175', 'uploads/lazy.jpg', 'Running, Sleeping, Cuddling, Purring', '2024-01-11 10:04:08', 'APPROVED'),
(12, 'Phiona', 1, 'Cat', 'puspin', 'Newport', '09173260175', 'uploads/phiona.jpg', 'Running, Playing, Exploring, Chasing, Digging, Purring', '2024-01-11 10:05:15', 'APPROVED'),
(13, 'Stripy', 1, 'Cat', 'puspin', 'Newport', '09173260175', 'uploads/stripy.jpg', 'Playing, Sleeping, Eating, Cuddling, Chasing, Purring', '2024-01-11 10:06:04', 'APPROVED'),
(14, 'whitey', 1, 'Cat', 'puspin', 'Newport', '09173260175', 'uploads/whitey.jpg', 'Running, Playing, Sleeping, Eating, Exploring, Chasing', '2024-01-11 10:07:30', 'APPROVED'),
(17, 'ginger', 1, 'Cat', 'aspin', 'Newport', '09173260175', 'uploads/ginger.JPG', 'Sleeping, Eating, Climbing, Bouncing', '2024-01-11 10:48:04', 'ADOPTED'),
(18, 'blacky', 1, 'Cat', 'puspin', 'Newport', '09173260175', 'uploads/blacky.jpg', 'Running, Playing, Digging, Hunting, Climbing', '2024-01-11 10:48:56', 'APPROVED'),
(19, 'cookie', 2, 'Dog', 'aspin', 'Newport', '09173260175', 'uploads/cookie.jpg', 'Running, Playing, Pouncing, Snuggling, Digging, Hunting', '2024-01-11 10:54:26', 'APPROVED'),
(20, 'panda', 2, 'Dog', 'aspin', 'Newport', '09173260175', 'uploads/panda.jpg', 'Running, Playing, Sleeping, Exploring, Pouncing, Bouncing, Rolling', '2024-01-11 10:54:57', 'ADOPTED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adoption`
--
ALTER TABLE `adoption`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `intake`
--
ALTER TABLE `intake`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adoption`
--
ALTER TABLE `adoption`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `intake`
--
ALTER TABLE `intake`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
