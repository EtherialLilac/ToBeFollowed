<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.icon" rel="icon">


    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
        <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link active">About Us</a>
                    <a href="donate.php" class="nav-item nav-link">Donate</a>
                    <a href="adopt.php" class="nav-item nav-link">Adopt</a>
					<a href="intake.php" class="nav-item nav-link">Intake & Foster</a>
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

<!--intro-->
    <div class="container mt-5">
  <div class="text-center">
    <h1 style="color: blue; font-family: Arial;" class="stylish-text"><b>CATS OF NEWPORT CITY</b></h1><br>
    <p style="color:black; size: 20px;" class="intro-text">Presented by: Samantha B. Allen, Founder<br>
Homeowner and Resident<br><br>
at Residential Resort Newport since 2013<br>
Animal Welfare Advocate
</p>
  </div>
</div>
<br><br><br>
<hr>
<!---INTRODUCTION---->

<div class="container">
    <div class="row">
        <div class="col-md-4">
              <div class="card-body">
                <h5 class="card-title"><b>INTRODUCTION</b></h5><br>
                <p style="text-align: justify; color:black;" class="card-text">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.
Cats of Newport City is not a shelter.</p><br>
<a href="https://drive.google.com/file/d/1AXzNgab5esCwx6sphQMmdm5ZNPyDcILf/view?usp=drive_link" target="_blank"><button>Click to view more</button></a>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card-body">
                <h5 class="card-title"><b>EFFORTS AND PARTNERS</b></h5><br>
                <p style="text-align: justify; color:black;" class="card-text"><b>Partners: CARA Welfare Philippines and Pawssion Project</b>

<br><br>Newport City: Caught-Spayed/Neutered-Vaccinated-Returned to date: 116 cats
Adoptions to date: 97 Newport City cats</p><br><br>
            <a href="https://drive.google.com/file/d/1-2WQ-368JzXkg8ODHBOf8gylMtSw5mIb/view?usp=sharing" target="_blank"><button>Click to view more</button></a>
              </div>
            </div>

            
            <div class="col-md-4">
              <div class="card-body">
                <h5 class="card-title"><b>PRE-CAUTIONS</b></h5><br><br>
                <p style="text-align: justify; color:black;" class="card-text">CAT ADVOCACY SIGNAGES</p><br><br><br><br><br><br>
            <a href="https://drive.google.com/file/d/16I3kTbDe0ve7lb1DPrWvhSH9mMxPBeSv/view?usp=drive_link" target="_blank"><button>Click to view more</button></a>
              </div>
            </div>


          <!--/div><div class="col-md-4">
            <div class="photo-card">
              <img src="img/dog1.jpg" class="card-img-top" alt="Sample Image">
              <div class="card-body">
                <h5 class="card-title">Card Title</h5>
                <p class="card-text">Some quick example text to describe the photo. This could include details about the image or its context.</p>
                <br><br><br><br><br><br>
                <a href="sponsorform.html" class="btn btn-primary">Sponsor</a>
              </div>
            </div>
          </div><div class="col-md-4">
            <div class="photo-card">
              <img src="img/cat2.jpg" class="card-img-top" alt="Sample Image">
              <div class="card-body">
                <h5 class="card-title">Card Title</h5>
                <p class="card-text">Some quick example text to describe the photo. This could include details about the image or its context.</p>
                <a href="sponsorform.html" class="btn btn-primary">Sponsor</a>
              </div>
            </div>
          </div>
      <-- Replicate this structure for additional cards -->
      <!-- <div class="col-md-4">
            Additional photo card content here
          </div> ---->
    </div>
  </div>

  <!----end of intro-->

  <br><br><br><br>
<hr>
    <!-- ABout Start -->
    <div class="container pt-5">
	<div class="row">
			<div class="col-lg-6 mb-3">
                <div class="card border-0 mb-2">   
                    <div class="card-body p-4">
                        <h2 class="card-title text-truncate">The goals of Cats of Newport <br>City are to:</h2>
						<h4 class="card-title text-truncate ml-2">----------</h4>
						<p class="ml-3">(1) Encourage compassion and peaceful co-existence with our community cats;</p>
						<p class="ml-3">(2) Promote catch-spay/neuter-vaccinate-return (CNVR) efforts to humanely 
                        control the growing stray cat population in the community;</p>
						<p class="ml-3">(3) Educate the township on activities that will help support the wellbeing of our community cats : fostering, 
                            rehabilitation, and when possible, adoption.</p>
                    </div>
					
                </div>
            </div>
			
			<div class="col-lg-6 mb-3">
                <div class="card border-0 mb-2">   
                  
					<img class="card-img-top" src="img/intro.png" alt="">
                </div>
            </div>  
	    </div>	

    </div>
    <!-- ABout End -->






<br>
<br>





    <!-- ABout Start -->
    <div class="container pt-5">
	
	<center>
	<h2 class="card-title text-truncate">WHAT CAN BE DONE?</h2>
	</center>

<br>
	<center>
	<div class="row">


	
			<!--div class="col-lg-5 mb-3 mx-auto" style="background-color: #ED6436; border-radius: 15px; margin: 20px;" >
                <div class="card border-2 mb-2 mt-2">   
				<center>
                    <div class="card-body p-4">
                        <h3 class="card-title text-truncate">MISSION</h3>

                    </div>
				</center>
                </div>
            </div>


	
			<div class="col-lg-5 mb-3 mx-auto" style="background-color: #ED6436; border-radius: 15px; margin: 20px;" >
                <div class="card border-2 mb-2 mt-2">   
				<center>
                    <div class="card-body p-4">
                        <h3 class="card-title text-truncate">VISiON</h3>

                    </div>
				</center>
                </div>
            </div>


	</div---->	
	</center>

  <p class="m-0">1. Partner with Cats of Newport City @catsofnewportcitypasay and
CARA Welfare Philippines https://www.caraphil.org<br><br>

2. Implement sustained activities of CNVR (Catch-Spay/Neuter-
Vaccinate-Return) to humanely control cat population<br><br>

• Spaying or neutering alters the behavior of cats; they are more tame and do not seek
mates while protecting their territories from other unfixed cats.<br>
• The result as seen in Residential Resort Newport is an 80% decrease in female cats
producing offspring within just 6 months from when we started.<br>
• The cost of the fixing will be paid to CARA who will conduct catching, surgery,
vaccination, post-surgery care and return of the cats.<br><br>

3. Feed cats 2x daily in discreet, designated areas hidden from the public<br><br>
4. Option to build a cattery like Ascott Hotel<br><br>
5. Develop and put up signs like:<br><br>
• Brake for cats: “Slow down, cats in the area”<br>
• Feeding guidelines<br>
• Discourage people from touching the cats to avoid negative interactions hence
avoiding liability also for Administration officers</p>
  
   </div>
    <!-- ABout End -->





<br>
<br>
<hr style="width: 70%;">





    <!-- spaynueter Start -->

    <!--div class="container pt-5">
        <div class="d-flex flex-column text-center mb-5">
            <h1 class="display-5 m-0"><span class="text-primary">Spay and Neuter</span> Program</h1>
        </div>
        <div class="row pb-3">
		
		
            <div class="col-lg-12 mb-4">
                <div class="card border-0 mb-2">
                   
                    <div class="card-body bg-light p-4">
                       
			<center>   
                        <p>INFOS HERE IN PARA FORM Diam amet eos at no eos sit lorem, amet rebum ipsum clita stet, diam sea est diam eos, rebum sit vero stet justo</p>
          
						<a href="appointment.php" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">Set an Appointment</a>
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div-->
    <!-- spaynueter End -->


   <!-- Footer Start -->
   <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/65b26bcd8d261e1b5f57e5db/1hl0fa7lo';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

    <!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>