<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
        <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link active">Home</a>
                   
					
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->


    <!-- Carousel Start -->
    <div class="container-fluid p-0">
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
			
			
                <div class="carousel-item active">
                    <img class="w-100" src="img/co.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h3 class="text-white mb-3 d-none d-sm-block">ADMIN LOGIN</h3>
                            
								<div class="row mt-2 mb-2">
				
								<div class="col">
										<input type="text" class="form-control" id="username" name="username" placeholder="Username">
								</div>
									
								</div>
								
								<div class="row mt-2 mb-2">
				
								<div class="col">
										<input type="password" class="form-control" id="password" name="password"  placeholder="Password">
								</div>
								
								</div>
				
                 
							<hr style="margin: 0px;">
                            <a onclick="login()" class="btn btn-lg btn-secondary mt-3 mt-md-4 px-4">LOGIN</a>
							
                        </div>
                    </div>
                </div>
                
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-primary rounded" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-primary rounded" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>
    <!-- Carousel End -->





    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	
<script>
function login() {
    if (document.getElementById("username").value == "admin" && document.getElementById("password").value == "huamin") {
        // Set a value in localStorage for session status
        localStorage.setItem("session_status", "SESSION_ACTIVE");
        window.location = "adminadoption.php";
    } else {
        alert("INVALID USERNAME OR PASSWORD");
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
    }
}

function logout() {
    // Clear the value in localStorage for session status
    localStorage.removeItem("session_status");
}

// Automatically log out on page load
logout();

// Listen for the Enter key press event on the password field
document.getElementById("password").addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        login();
    }
});

// Function to check session status
function checkSession() {
    if (!localStorage.getItem("session_status")) {
        logout();
        // Redirect to login page if not logged in
        window.location = "adminlogin.php";
    }
}

</script>

</body>

</html>