<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	
	
	<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap CSS -->
<lidnk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<!-- Bootstrap JS (Bundle) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Bootstrap Multiselect CSS -->
<lindk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/css/bootstrap-multiselect.min.css">

<!-- Bootstrap Multiselect JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/js/bootstrap-multiselect.min.js"></script>



</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
        <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link ">About Us</a>
                    <a href="donate.php" class="nav-item nav-link ">Donate</a>
                    <a href="adopt.php" class="nav-item nav-link active">Adopt</a>
					<a href="intake.php" class="nav-item nav-link">Intake & Foster</a>
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->







<br>
<br>
<hr style="width: 70%;">





    <!-- spaynueter Start -->
    <div class="container pt-5">
       
        <div class="row pb-3">
		
		
            <div class="col-lg-10 mx-auto mb-4">
                <div class="card border-0 mb-2"> 
                    <div class="card-body bg-light p-4">
                       
					   
		<div class="d-flex flex-column text-left mb-5">
            <h3 class="display-5 m-0"><span class="text-primary">PET-HUMAN PAIRING</h3>
        </div>
		
			<center>   
			
 
  <!-- Checkbox Modal -->
  <div class="modal fade" id="checkboxModal" tabindex="-1" role="dialog" aria-labelledby="checkboxModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="checkboxModalLabel">Select Your Preferences</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          
		    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Running" id="running" name="activities[]">
      <label class="form-check-label" for="running">Loves to Run</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Playing" id="playing" name="activities[]">
      <label class="form-check-label" for="playing">Active in Playing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Sleeping" id="sleeping" name="activities[]">
      <label class="form-check-label" for="sleeping">Enjoys Sleeping</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Eating" id="eating" name="activities[]">
      <label class="form-check-label" for="eating">Active in Eating</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Exploring" id="exploring" name="activities[]">
      <label class="form-check-label" for="exploring">Loves Exploring</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Cuddling" id="cuddling" name="activities[]">
      <label class="form-check-label" for="cuddling">Enjoys Cuddling</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Chasing" id="chasing" name="activities[]">
      <label class="form-check-label" for="chasing">Loves Chasing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Swimming" id="swimming" name="activities[]">
      <label class="form-check-label" for="swimming">Active in Swimming</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Basking" id="basking" name="activities[]">
      <label class="form-check-label" for="basking">Enjoys Basking</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Pouncing" id="pouncing" name="activities[]">
      <label class="form-check-label" for="pouncing">Loves Pouncing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Snuggling" id="snuggling" name="activities[]">
      <label class="form-check-label" for="snuggling">Enjoys Snuggling</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Digging" id="digging" name="activities[]">
      <label class="form-check-label" for="digging">Active in Digging</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Hunting" id="hunting" name="activities[]">
      <label class="form-check-label" for="hunting">Loves Hunting</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Grooming" id="grooming" name="activities[]">
      <label class="form-check-label" for "grooming">Active in Grooming</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Climbing" id="climbing" name="activities[]">
      <label class="form-check-label" for="climbing">Loves Climbing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Chirping" id="chirping" name="activities[]">
      <label class="form-check-label" for="chirping">Active in Chirping</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Bouncing" id="bouncing" name="activities[]">
      <label class="form-check-label" for="bouncing">Loves Bouncing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Sunbathing" id="sunbathing" name="activities[]">
      <label class="form-check-label" for="sunbathing">Active in Sunbathing</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Rolling" id="rolling" name="activities[]">
      <label class="form-check-label" for="rolling">Loves Rolling</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" value="Purring" id="purring" name="activities[]">
      <label class="form-check-label" for="purring">Active in Purring</label>
    </div>
	

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary"  id="saveButton"  data-dismiss="modal"> Save Preferences</button>
        </div>
      </div>
    </div>
  </div>

        
  
<form>


    <div class="row mt-2 mb-2">
        <div class="col-6 mx-auto">
		  <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#checkboxModal" style="width: 100%;" id="lfsbtn">
			Choose Lifestyle
		  </button>
        </div>
    </div>

	
	  <!-- JavaScript -->
  <script>
    document.getElementById('saveButton').addEventListener('click', function () {
      const checkboxes = document.querySelectorAll('input[name="activities[]"]:checked');
      const selectedActivities = Array.from(checkboxes).map(checkbox => checkbox.value.toLowerCase()).join(',');
      //alert(`${selectedActivities}`);
	  document.getElementById("lfsbtn").innerHTML = `${selectedActivities}`.toUpperCase() ;
	  
    });
  </script>

  

    <div class="row mt-2 mb-2" style="display: none;">
        <div class="col-6 mx-auto">
            <div class="dropdown">
                <button id="lifestyle" class="btn btn-dark dropdown-toggle" type="button" id="lifestyleDropdownButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 100%;">
                    Lifestyle
                </button>
                <div class="dropdown-menu" aria-labelledby="lifestyleDropdownButton">
                    <a class="dropdown-item" value="Active and Outdoorsy">Active and Outdoorsy</a>
                    <a class="dropdown-item" value="Quiet and Introverted">Quiet and Introverted</a>
                    <a class="dropdown-item" value="Busy Professional">Busy Professional</a>
                    <a class="dropdown-item" value="Family-Oriented">Family-Oriented</a>
                    <a class="dropdown-item" value="Urban Dweller">Urban Dweller</a>
                    <a class="dropdown-item" value="Social and Active">Social and Active</a>
                    <a class="dropdown-item" value="Homebody">Homebody</a>
                    <a class="dropdown-item" value="Elderly or Retiree">Elderly or Retiree</a>
                    <a class="dropdown-item" value="Adventurous Traveler">Adventurous Traveler</a>
                </div>
            </div>
        </div>
    </div>
	
	
	
	

    <div class="row mt-2 mb-2">
        <div class="col-6 mx-auto">
            <div class="dropdown">
                <button id="pettype" class="btn btn-dark dropdown-toggle" type="button" id="petTypeDropdownButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 100%;">
                    Type of Pet
                </button>
                <div class="dropdown-menu" aria-labelledby="petTypeDropdownButton">
                    <a class="dropdown-item" value="Dog">Dog</a>
                    <a class="dropdown-item" value="Cat">Cat</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2 mb-2">
        <div class="col-6 mx-auto">
            <input type="number" class="form-control" id="petage" name="petage" placeholder="Age of pet you want">
        </div>
    </div>
</form>

    <button type="submit" onclick="pair()" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">SUBMIT</button>

<script>
    $(document).ready(function() {
        $('.dropdown-item').click(function() {
            var selectedValue = $(this).attr('value');
            var parentDropdown = $(this).closest('.dropdown');
            var dropdownButton = parentDropdown.find('.dropdown-toggle');
            dropdownButton.text(selectedValue);
        });
    });
	
	
	function pair() {
		var life = document.getElementById("lfsbtn").textContent.trim();
		var type = document.getElementById("pettype").textContent.trim();
		var age = document.getElementById("petage").value.trim();
		
		if (life !== "Choose Lifestyle" && type !== "Type of Pet" && age !== "") {
			if (!isNaN(age) && parseFloat(age) !== 0) {
				//alert(life + " " + type + " " + age);
				window.location = "adoptlist.php?lifestyle="+life+"&type="+type+"&age="+age;
			} else {
				alert("Please enter a valid age.");
			}
		} else {
			alert("Please select lifestyle, pet type, and enter age.");
		}
	}

</script>

					 
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div>
    <!-- spaynueter End -->



<br>
<br>
<hr style="width: 70%;">





    <!-- sponsor Start -->
    <div class="container pt-5">
        
        <div class="row">
		
		
            <div class="col-lg-4 mb-4 mx-auto">
				<center>
					<h4>DONATE VIA PAYPAL</h4>
					<a href="donatenow.php" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">DONATE</a>
				</center>
            </div>
			

			<div class="col-lg-4 mb-4 mx-auto">
					<center>
						<h5>Account Name: Huamin</h5>
						<h5>Account Number: 1888-70015305</h5>
					</center>
			</div>
				
			
			
			<div class="col-lg-4 mb-4 mx-auto">
				<center>
					<h4>DONATE VIA GCASH</h4>
					<img src="img/qr.jpg" style="width: 40%; height: 40%"/>
				</center>
            </div>
			
		</div>		
   </div>
    <!-- sponsor End -->
















    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.7.0.slim.min.js" integrity="sha256-tG5mcZUtJsZvyKAxYLVXrmjKBVLd6VpVccqz/r4ypFE=" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>