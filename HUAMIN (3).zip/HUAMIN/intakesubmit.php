<?php
include 'dbconfig.php';

$dbHost = $host;
$dbUser = $username;
$dbPass = $password;
$dbName = $database;

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selectedActivities = isset($_POST['activities']) ? $_POST['activities'] : array();
$activities = implode(", ", $selectedActivities); // Combine selected activities into a comma-separated string

$petname = $_POST['petname'];
$petage = $_POST['petage'];
$petType = $_POST['petType'];
$petbreed = $_POST['petbreed'];
$gname = $_POST['gname'];
$gnumber = $_POST['gnumber'];

// Image upload handling
$targetDir = "uploads/"; // Change this to your desired upload directory
$targetFile = $targetDir . basename($_FILES["petimage"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// ... Check image file, size, and format ...

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
} else {
    if (move_uploaded_file($_FILES["petimage"]["tmp_name"], $targetFile)) {
        $activities = isset($_POST['activities']) ? implode(", ", $_POST['activities']) : '';

        // Insert data into the database
        $sql = "INSERT INTO intake (petname, petage, petType, petbreed, guardian_name, guardian_contact, petimage, activities)
                VALUES ('$petname', '$petage', '$petType', '$petbreed', '$gname', '$gnumber', '$targetFile', '$activities')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('REQUEST SUBMITTED! WE WILL GET IN TOUCH!'); window.location='intake.php';</script>";
        } else {
            echo "<script>alert('SOMETHING WENT WRONG!'); window.location='intake.php';</script>";
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
