<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	
	
		<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap CSS -->
<lidnk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<!-- Bootstrap JS (Bundle) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Bootstrap Multiselect CSS -->
<lindk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/css/bootstrap-multiselect.min.css">

<!-- Bootstrap Multiselect JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/js/bootstrap-multiselect.min.js"></script>




</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
        <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link ">About Us</a>
                    <a href="donate.php" class="nav-item nav-link ">Donate</a>
                    <a href="adopt.php" class="nav-item nav-link ">Adopt</a>
					<a href="intake.php" class="nav-item nav-link active">Intake & Foster</a>
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->







<br>
<br>
<hr style="width: 70%;">





    <!-- spaynueter Start -->
    <div class="container pt-5">
       
        <div class="row pb-3">
		
		
            <div class="col-lg-10 mx-auto mb-4">
                <div class="card border-0 mb-2"> 
                    <div class="card-body bg-light p-4">
                       
					   
		<div class="d-flex flex-column text-left mb-5">
            <h3 class="display-5 m-0"><span class="text-primary">Application for Intake & Foster</h3>
        </div>
		
			<center>   
	
			 <form id="adoptionForm" action="intakesubmit.php" method="POST" enctype="multipart/form-data">
           
			
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="text" class="form-control" id="petname" name="petname" placeholder="Pet Name">
				</div>
					
				<div class="col">
						<input type="number" class="form-control" id="petage" name="petage"  placeholder="Pet Age">
				</div>
				
				</div>
						

				<div class="row mt-2 mb-2">
					<div class="col">
							<div class="dropdown">
								<button id="petTypeDropdownButton" class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 100%; border: 1px gray solid;">
									Pet Type
								</button>
								<div class="dropdown-menu" aria-labelledby="petTypeDropdownButton">
									<a class="dropdown-item" href="#" data-value="Dog">Dog</a>
									<a class="dropdown-item" href="#" data-value="Cat">Cat</a>
								</div>
								<!-- Add a hidden input field to store the selected value -->
								<input type="hidden" id="petTypeInput" name="petType">
							</div>
						</div>
						<script>
							// Get the dropdown items
							var dropdownItems = document.querySelectorAll(".dropdown-item[data-value]");

							// Add click event listener to each dropdown item
							dropdownItems.forEach(function(item) {
								item.addEventListener("click", function() {
									var selectedValue = item.getAttribute("data-value");
									document.getElementById("petTypeInput").value = selectedValue;
									document.getElementById("petTypeDropdownButton").innerHTML = selectedValue;
								});
							});
						</script>

					
					<div class="col">
						<input type="text" class="form-control" id="petbreed" name="petbreed"  placeholder="Pet Breed">
					</div>
					
				</div>
				
				
				
				<br>
				<h5>Upload Pet Image</h5>
				<div class="row mt-2 mb-2">			
				<div class="col">
						<input type="file" class="form-control" id="petimage" name="petimage">
				</div>
				</div>
				
				
				<br>
				
				
				
				
<div class="row mt-2 mb-2">
    <div class="col">
        <h5>What does your pet love to do?</h5>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Running" id="running" name="activities[]">
            <label class="form-check-label" for="running">Running</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Playing" id="playing" name="activities[]">
            <label class="form-check-label" for="playing">Playing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Sleeping" id="sleeping" name="activities[]">
            <label class="form-check-label" for="sleeping">Sleeping</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Eating" id="eating" name="activities[]">
            <label class="form-check-label" for="eating">Eating</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Exploring" id="exploring" name="activities[]">
            <label class="form-check-label" for="exploring">Exploring</label>
        </div>
        <!-- Repeat the same structure for other checkboxes -->
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Cuddling" id="cuddling" name="activities[]">
            <label class="form-check-label" for="cuddling">Cuddling</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Chasing" id="chasing" name="activities[]">
            <label class="form-check-label" for="chasing">Chasing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Swimming" id="swimming" name="activities[]">
            <label class="form-check-label" for="swimming">Swimming</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Basking" id="basking" name="activities[]">
            <label class="form-check-label" for="basking">Basking</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Pouncing" id="pouncing" name="activities[]">
            <label class="form-check-label" for="pouncing">Pouncing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Snuggling" id="snuggling" name="activities[]">
            <label class="form-check-label" for="snuggling">Snuggling</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Digging" id="digging" name="activities[]">
            <label class="form-check-label" for="digging">Digging</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Hunting" id="hunting" name="activities[]">
            <label class="form-check-label" for="hunting">Hunting</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Grooming" id="grooming" name="activities[]">
            <label class="form-check-label" for="grooming">Grooming</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Climbing" id="climbing" name="activities[]">
            <label class="form-check-label" for="climbing">Climbing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Chirping" id="chirping" name="activities[]">
            <label class="form-check-label" for="chirping">Chirping</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Bouncing" id="bouncing" name="activities[]">
            <label class="form-check-label" for="bouncing">Bouncing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Sunbathing" id="sunbathing" name="activities[]">
            <label class="form-check-label" for="sunbathing">Sunbathing</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Rolling" id="rolling" name="activities[]">
            <label class="form-check-label" for="rolling">Rolling</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="checkbox" value="Purring" id="purring" name="activities[]">
            <label class="form-check-label" for="purring">Purring</label>
        </div>
    </div>
</div>


				
				
				<br>
				
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="text" class="form-control" id="gname" name="gname"  placeholder="Guardian Name">
				</div>
					
				<div class="col">
						<input type="number" class="form-control"  id="gnumber" name="gnumber" placeholder="Guardian Contact">
				</div>
				
				</div>




            <button type="submit" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">SUBMIT</button>


			</form>

				
					
						
					 
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div>
    <!-- spaynueter End -->

<script>

    $(document).ready(function() {
        $('.dropdown-item').click(function() {
            var selectedValue = $(this).attr('value');
            var parentDropdown = $(this).closest('.dropdown');
            var dropdownButton = parentDropdown.find('.dropdown-toggle');
            dropdownButton.text(selectedValue);
        });
    });
	

	function intakesubmit() {
    // Prevent the default form submission
    event.preventDefault();

    // Gather form data
    var formData = new FormData(document.getElementById('adoptionForm'));

    // Send form data using AJAX
    $.ajax({
        type: 'POST',
        url: 'intakesubmit.php', // Replace with the correct URL of your PHP script
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            alert("Data saved successfully!");
            location.reload();
        },
        error: function() {
            alert("Error saving data.");
        }
    });
}



</script>









    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>

    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>