<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pawsome</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	
	
		<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap CSS -->
<lidnk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<!-- Bootstrap JS (Bundle) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Bootstrap Multiselect CSS -->
<lindk rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/css/bootstrap-multiselect.min.css">

<!-- Bootstrap Multiselect JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-multiselect@0.11.0/dist/js/bootstrap-multiselect.min.js"></script>




</head>

<body>

    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-lg-5">
            <a href="" class="navbar-brand d-block d-lg-none">
                <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
			
			
	 <div class="row py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="" class="navbar-brand d-none d-lg-block">
                    <img src="img/LogoNPC.jpg.png" alt="Pawsome Logo" width="150">
                </a>
            </div>          
        </div>
		
		
                <div class="navbar-nav ml-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link ">About Us</a>
                    <a href="donate.php" class="nav-item nav-link ">Donate</a>
                    <a href="adopt.php" class="nav-item nav-link active">Adopt</a>
					<a href="intake.php" class="nav-item nav-link">Intake & Foster</a>
                    
                </div>
                
            </div>
        </nav>
    </div>
    <!-- Navbar End -->







<br>
<br>
<hr style="width: 70%;">





    <!-- spaynueter Start -->
    <div class="container pt-5">
       
        <div class="row pb-3">
		
		
            <div class="col-lg-10 mx-auto mb-4">
                <div class="card border-0 mb-2"> 
                    <div class="card-body bg-light p-4">
                       
					   
		<div class="d-flex flex-column text-left mb-5">
            <h3 class="display-5 m-0"><span class="text-primary">Application for Adoption</h3>
        </div>
		
			<center>   
			
				<p>***** INPUT YOUR INFORMATIONS HONESTLY *****</p>
					 
			<form>
			
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="text" class="form-control" id="fname" name="fname" placeholder="Adopter First Name">
				</div>
					
				<div class="col">
						<input type="text" class="form-control" id="lname" name="lname"  placeholder="Adopter Last Name">
				</div>
				
				</div>
				
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="text" class="form-control" id="address" name="address"  placeholder="Complete Address">
				</div>
					
				<div class="col">
						<input type="number" class="form-control" id="age" name="age"  placeholder="Age">
				</div>
				
				</div>
				
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="number" class="form-control" id="cellnumber" name="cellnumber"  placeholder="Cell Number">
				</div>
					
				<div class="col">
						<input type="number" class="form-control"  id="altercell" name="altercell" placeholder="Alternative Contact">
				</div>
				
				</div>
				
				
				
				<div class="row mt-2 mb-2">
				
				<div class="col">
						<input type="text" class="form-control" id="occupation" name="occupation"  placeholder="Occupation">
				</div>
					
				<div class="col">
						<input type="email" class="form-control"  id="email" name="email" placeholder="Email">
				</div>
				
				</div>


				<div class="row mt-2 mb-2">
					<div class="col">
						<div class="dropdown">
							<button id="gender" class="btn btn-light dropdown-toggle" type="button" id="petTypeDropdownButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 100%; border: 1px gray solid;">
								Gender
							</button>
							<div class="dropdown-menu" aria-labelledby="petTypeDropdownButton">
								<a class="dropdown-item" value="Female">Female</a>
								<a class="dropdown-item" value="Male">Male</a>
							
							</div>
						</div>
					</div>
					<div class="col">
						<div class="input-group">
							<input type="date" class="form-control" id="date" name="date" placeholder="Date of Appointment" data-provide="datepicker">
							<div class="input-group-addon">
								<span class="glyphicon glyphicon-th"></span>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="input-group">
							<input type="time" class="form-control" id="time" name="time" placeholder="Time of Appointment" data-provide="clockpicker">
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-time"></span>
							</span>
						</div>
					</div>
				</div>


			</form>

				
					<button type="submit" onclick="adoptsubmit()" class="btn btn-lg btn-primary mt-3 mt-md-4 px-4">SUBMIT</a>
						
					 
			</center>
	
                    </div>
                </div>
            </div>
			

		
        </div>	
			
   </div>
    <!-- spaynueter End -->

<script>

    $(document).ready(function() {
        $('.dropdown-item').click(function() {
            var selectedValue = $(this).attr('value');
            var parentDropdown = $(this).closest('.dropdown');
            var dropdownButton = parentDropdown.find('.dropdown-toggle');
            dropdownButton.text(selectedValue);
        });
    });
	

	function adoptsubmit() {
		
	
			var currentUrl = window.location.href;
			var urlSearchParams = new URLSearchParams(new URL(currentUrl).search);

			var idParameter = urlSearchParams.get("id");
			var petname = urlSearchParams.get("petname");
			var fname = document.getElementById("fname").value.trim();
			var lname = document.getElementById("lname").value.trim();
			var address = document.getElementById("address").value.trim();
			var age = document.getElementById("age").value.trim();
			var cellnum = document.getElementById("cellnumber").value.trim();
			var altnum = document.getElementById("altercell").value.trim();
			var occupation = document.getElementById("occupation").value.trim();
			var email = document.getElementById("email").value.trim();	
			var gender = document.getElementById("gender").textContent.trim();
			var date = document.getElementById("date").value.trim();
			var time = document.getElementById("time").value.trim();
			
			if (
				 document.getElementById("fname").value.trim() != "" && 
				 document.getElementById("lname").value.trim() != "" && 
				 document.getElementById("address").value.trim() != "" && 
				 document.getElementById("age").value.trim() != "" && 
				 document.getElementById("cellnumber").value.trim() != "" && 
				 document.getElementById("altercell").value.trim() != "" && 
				 document.getElementById("occupation").value.trim() != "" && 
				 document.getElementById("gender").textContent.trim() != "Gender" && 
				 document.getElementById("date").value.trim() != "" && 
				 document.getElementById("time").value.trim() != ""
			) {
				window.location = `adoptsubmit.php?id=${idParameter}&fname=${fname}&lname=${lname}&address=${address}&age=${age}&cellnum=${cellnum}&altnum=${altnum}&occupation=${occupation}&email=${email}&gender=${gender}&date=${date}&time=${time}&petname=${petname}`;
			} else {
				alert("Please fill in all required fields.");
			}

		}


</script>









    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white mt-5 py-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            <div class="col-lg-6 col-md-12 mb-5">
                <h1 class="mb-3 display-5 text-capitalize text-white"><span class="text-primary">Cats</span> of Newport</h1>
                <p class="m-0">Cats of Newport City was founded in 2021 at the height of the
pandemic. Prior to founding the group, I was already an active animal
welfare advocate and volunteer for the country’s biggest animal
welfare organization, Pawssion Project, since 2018.</p>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="row">
				
				  <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Address</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Newport City, Pasay</p>
                     
                    </div>
					
					
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary mb-4">Contact Us</h5>
            
                        <p><i class="fa fa-phone-alt mr-2"></i>09173260175</p>
                        <p><i class="fa fa-envelope mr-2"></i>newportcitycats@gmail.com</p>
                        <div class="d-flex justify-content-start mt-4">
                            <a class="btn btn-outline-light rounded-circle text-center mr-2 px-0" style="width: 36px; height: 36px;" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
 
           
                </div>
            </div>
        </div>
    </div>


    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>